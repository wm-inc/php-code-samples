<?php

namespace AppBundle\Service;

use Aws\S3\S3Client;

/**
 * Class S3ClientFactory
 * @package AppBundle\Service
 */
class S3ClientFactory
{

    /**
     * @return S3Client
     */
    public function getInstance( array $config ): S3Client
    {
        $s3Client = new S3Client([
            'version' => 'latest',
            'region' => $config['region'],
            'credentials' => [
                'key' => $config['key'],
                'secret' => $config['secret'],
            ],
        ]);

        return $s3Client;
    }

}
