<?php

namespace AppBundle\Service;

use Aws\S3\S3Client;
use Aws\CloudFront\Exception\CloudFrontException;
use Aws\CloudFront\Exception\S3Exception;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\LoggerInterface;
use Psr\Log\LoggerTrait;
use Symfony\Component\Filesystem\Exception\FileNotFoundException;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Class ImageService
 * @package AppBundle\Service
 */
class ImageService
{
    use LoggerAwareTrait;
    use LoggerTrait;

    /**
     * @var int
     */
    private $width;

    /**
     * @var int
     */
    private $height;

    /**
     * @var int
     */
    private $fileSize;

    /**
     * @var string
     */
    private $absoluteImageSource;

    /**
     * @var string
     */
    private $absoluteImageDestination;

    /**
     * @var int
     */
    private $quality;

    /**
     * @var array
     */
    private $allowedType;

    /**
     * @var int
     */
    private $minHeight;

    /**
     * @var int
     */
    private $minWidth;

    /**
     * @var int
     */
    private $maxWidth;

    /**
     * @var bool
     */
    private $success;

    /**
     * @var bool
     */
    private $deleteInvalid;
    /**
     * @var S3Client
     */
    private $s3Client;

    /**
     * @var S3Client
     */
    private $s3Bucket;
    /**
     * @var Filesystem
     */
    private $fileSystem;
    /**
     * @var array
     */
    private $config;
    /**
     * @var ContentDeliveryNetwork\CdnProviderInterface
     */
    private $cdnClient;

    /**
     * [__construct description]
     * @param FileSystem $filesystem [description]
     * @param S3ClientFactory $s3ClientFactory [description]
     * @param LoggerInterface $logger
     */
    public function __construct(
        FileSystem $filesystem,
        LoggerInterface $logger,
        S3ClientFactory $s3ClientFactory,
        array $config,
        ContentDeliveryNetwork\CdnProviderFactory $cdnProviderFactory
    ) {
        $this->config = $config;
        $this->s3Client = $s3ClientFactory->getInstance($config);
        if ( isset( $config['cdn'] ) ) {
            $this->cdnClient = $cdnProviderFactory->getInstance($config);
        }
        $this->setFileSystem($filesystem);
        $this->setAbsoluteImageSource('');
        $this->setAbsoluteImageDestination('');
        $this->setQuality(100);
        $this->setSuccess(false);
        $this->setDeleteInvalid(true);
        $this->setLogger($logger);
    }

    /**
     * Get the URL to the image (on AWS S3 or Cloudfront).
     * @param string $key
     * @param bool $cdn - Try for cdn url w/ fallback
     * @return null|string
     */
    public function getImageUrl( string $key, bool $cdn = true ): ?string {
        // Try for cdn url if configured, fallback to s3
        if ( $cdn and isset( $this->cdnClient ) ) {
            return sprintf(
                'https://%s/%s%s',
                $this->config['cdn']['host'],
                $this->config['cdn']['path'],
                $key
            );
        }
        else {
            return sprintf(
                'https://%s.s3.amazonaws.com/%s%s',
                $this->config['bucket'],
                $this->config['folder'],
                $key
            );
        }
    }

    /**
     * @param int $minHeight
     * @param int $minWidth
     * @param int $maxWidth
     * @param int $alloweFileSize
     * @param array $allowedFileType
     * @param string $imageSource
     * @param string $imageDestination
     */
    public function initializeImage(
        int $minHeight,
        int $minWidth,
        int $maxWidth,
        int $alloweFileSize,
        array $allowedFileType,
        string $imageSource,
        string $imageDestination
    ) {
        $this->setMinHeight($minHeight);
        $this->setMinWidth($minWidth);
        
        $this->setMaxWidth($maxWidth);
        $this->setFileSize($alloweFileSize);
        $this->setAllowedType($allowedFileType);
        $this->setAbsoluteImageSource($imageSource);
        $this->setAbsoluteImageDestination($imageDestination);
    }

    /**
     * @param $newWidth
     * @param $newHeight
     * @return bool
     * @throws \InvalidArgumentException
     */
    public function resize($newWidth, $newHeight)
    {

        if (empty($this->absoluteImageSource)) {
            trigger_error("Assign Image source path to property [absoluteImageSource]");
        }

        if (empty($this->absoluteImageDestination)) {
            trigger_error("Assign Image destination path to property [absoluteImageDestination]");
        }

        // Get image details
        $info = $this->getImageInfo();

        // Obtain image from given source file.
        switch ($info[2]) {
            case IMAGETYPE_JPEG:
                $image = imagecreatefromjpeg($this->absoluteImageSource);
                break;
            case IMAGETYPE_GIF:
                $image = imagecreatefromgif($this->absoluteImageSource);
                break;
            case IMAGETYPE_PNG:
                $image = imagecreatefrompng($this->absoluteImageSource);
                break;
            default:
                throw new \InvalidArgumentException(
                    __METHOD__ . '/Image not supported'
                );
        }

        // Get dimensions of source image.
        $origWidth = $info[0];
        $origHeight = $info[1];

        if ($newWidth == 0) {
            $newWidth = $origWidth;
        }

        if ($newHeight == 0) {
            $newHeight = $origHeight;
        }

        // Calculate ratio of desired maximum sizes and original sizes.
        $widthRatio = $newWidth / $origWidth;
        $heightRatio = $newHeight / $origHeight;

        // Ratio used for calculating new image dimensions.
        $ratio = min($widthRatio, $heightRatio);

        // Calculate new image dimensions.
        $newWidth = (int)$origWidth * $ratio;
        $newHeight = (int)$origHeight * $ratio;

        // Create final image with new dimensions.
        $newImage = imagecreatetruecolor($newWidth, $newHeight);

        imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

        switch ($info[2]) {
            case IMAGETYPE_GIF:
                imagegif($newImage, $this->absoluteImageDestination);
                break;
            case IMAGETYPE_JPEG:
                imagejpeg($newImage, $this->absoluteImageDestination, $this->quality);
                break;
            case IMAGETYPE_PNG:
                $this->calculatePngQuality();
                imagepng($newImage, $this->absoluteImageDestination, $this->getQuality());
                break;
            default:
                throw new \InvalidArgumentException(
                    __METHOD__ . '/Image not supported'
                );
        }
        // Free up the memory.
        imagedestroy($image);
        imagedestroy($newImage);
        return true;
    }

    public function calculatePngQuality()
    {
        $quality = 9 - (int)((0.9 * $this->quality)/10.0);
        $this->setQuality($quality);
    }
    /**
     * @return array
     */
    public function validate()
    {
        $image_info = getimagesize($this->absoluteImageSource);
        $size = filesize($this->absoluteImageSource);
        $errors = [];

        if ($image_info[0] > $this->maxWidth) {
            $errors[] = "Please Upload Smaller Image. Max Width ".$this->getMaxWidth()."px";
        }

        if (!in_array($image_info['mime'], $this->allowedType)) {
            $errors[] = "Please Upload Image in correct format. [".implode(', ', $this->allowedType).']';
        }

        if ($size > $this->fileSize) {
            $fileSize = $this->fileSize/1024;
            $errors[] = "Please Upload Image in of size less then ".$fileSize.' kb';
        }

        if (!empty($errors)) {
            if ($this->getDeleteInvalid()) {
                unlink($this->absoluteImageSource);
            }
            $this->success = false;
        } else {
            $this->success = true;
        }
        return $errors;
    }

    /**
     * @param string $filenameToSave
     * @param string $imageSource
     * @return bool
     */
    public function saveToS3(string $filenameToSave, string $imageSource):bool
    {
        $this->debug(
            __METHOD__ . '/S3 Bucket: ' . $this->config['bucket'] .
            ', source file name: ' . $imageSource .
            ', destination file name: ' . $filenameToSave
        );
        /**
         * @var S3Client $s3Client
         */

        $key = $this->config['folder'] . $filenameToSave;
        try {
            $result = $this->s3Client->putObject([
                'Bucket' => $this->config['bucket'],
                'Key' => $key,
                'SourceFile' => $imageSource,
                'ACL' => 'public-read',
            ]);
        }
        catch( S3Exception $e ) {
            $this->error('S3 Error: ' . $e);
        }
        $this->debug(
            __METHOD__ . '/putObject result: ' . (string) $result
        );
        if ( $result and $this->cdnClient ) {
            try {
                $cf_res = $this->cdnClient->invalidateFile($key);
                $this->debug(
                    __METHOD__ . '/invalidate result: ' . (string) $cf_res
                );
            }
            catch ( CloudFrontException $e ) {
                $this->error('Cloudfront Error: ' . $e->getAwsErrorMessage());
            }
        }
        if ($result) {
            return true;
        }
        return false;
    }

    /**
     * @param string $filepath
     * @param string $bucketName
     * @return bool
     */
    public function deleteFromS3(string $filepath):bool
    {
        /**
         * @var S3Client $s3Client
         */
        $result = $this->s3Client->deleteObject([
            'Bucket' => $this->config['bucket'],
            'Key' => $this->config['folder'] . $filepath
        ]);

        if ($result) {
            return true;
        }
        return false;
    }

    /**
     * @return array|bool
     */
    public function getImageInfo()
    {
        //@todo Return a model with image info rather than an array.
        $fs = $this->getFileSystem();

        if ($fs->exists($this->absoluteImageSource)) {
            $info = getimagesize($this->absoluteImageSource);
        } else {
            throw new FileNotFoundException('"' . $this->absoluteImageSource . '" not found');
        }
        return $info;
    }

    /**
     * @return bool
     */
    public function getDeleteInvalid()
    {
        return $this->deleteInvalid;
    }

    /**
     * @param bool $deleteInvalid
     */
    public function setDeleteInvalid(bool $deleteInvalid): void
    {
        $this->deleteInvalid = $deleteInvalid;
    }

    /**
     * @return int
     */
    public function getWidth(): int
    {
        return $this->width;
    }

    /**
     * @param int $width
     */
    public function setWidth(int $width)
    {
        $this->width = $width;
    }

    /**
     * @return int
     */
    public function getHeight(): int
    {
        return $this->height;
    }

    /**
     * @param int $height
     */
    public function setHeight(int $height)
    {
        $this->height = $height;
    }

    /**
     * @return int
     */
    public function getFileSize(): int
    {
        return $this->fileSize;
    }

    /**
     * @param int $fileSize
     */
    public function setFileSize(int $fileSize)
    {
        $this->fileSize = $fileSize;
    }

    /**
     * @return string
     */
    public function getAbsoluteImageSource(): string
    {
        return $this->absoluteImageSource;
    }

    /**
     * @param string $absoluteImageSource
     */
    public function setAbsoluteImageSource(string $absoluteImageSource)
    {
        $this->absoluteImageSource = $absoluteImageSource;
    }

    /**
     * @return string
     */
    public function getAbsoluteImageDestination(): string
    {
        return $this->absoluteImageDestination;
    }

    /**
     * @param string $absoluteImageDestination
     */
    public function setAbsoluteImageDestination(string $absoluteImageDestination)
    {
        $this->absoluteImageDestination = $absoluteImageDestination;
    }

    /**
     * @return int
     */
    public function getQuality()
    {
        return $this->quality;
    }

    /**
     * @param int $quality
     */
    public function setQuality($quality): void
    {
        $this->quality = $quality;
    }

    /**
     * @return int
     */
    public function getMinWidth(): int
    {
        return $this->minWidth;
    }

    /**
     * @param int $minWidth
     */
    public function setMinWidth(int $minWidth): void
    {
        $this->minWidth = $minWidth;
    }

    /**
     * @return int
     */
    public function getMinHeight(): int
    {
        return $this->minHeight;
    }

    /**
     * @param int $minHeight
     */
    public function setMinHeight(int $minHeight): void
    {
        $this->minHeight = $minHeight;
    }

    /**
     * @return int
     */
    public function getMaxWidth(): int
    {
        return $this->maxWidth;
    }

    /**
     * @param int $maxWidth
     */
    public function setMaxWidth(int $maxWidth): void
    {
        $this->maxWidth = $maxWidth;
    }

    /**
     * @return array
     */
    public function getAllowedType(): array
    {
        return $this->allowedType;
    }

    /**
     * @param array $types
     */
    public function setAllowedType(array $types)
    {
        $this->allowedType = $types;
    }

    /**
     * @param bool $success
     */
    public function setSuccess(bool $success): void
    {
        $this->success = $success;
    }

    /**
     * @return bool
     */
    public function isSuccess(): bool
    {
        return $this->success;
    }

    /**
     * @return Filesystem
     */
    public function getFileSystem(): Filesystem
    {
        return $this->fileSystem;
    }

    /**
     * @param Filesystem $fileSystem
     */
    public function setFileSystem(Filesystem $fileSystem): void
    {
        $this->fileSystem = $fileSystem;
    }

    /**
     * Logs with an arbitrary level.
     *
     * @param mixed $level
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    protected function log($level, $message, array $context = array())
    {
        $this->logger->log($level, $message, $context);
    }
}
