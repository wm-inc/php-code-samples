<?php

namespace AppBundle\Service;

use AppBundle\Entity\Promotions;
use AppBundle\Repository\PromotionsRepository;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\Mapping\ClassMetadata;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\LoggerInterface;
use Psr\Log\LoggerTrait;
use Common\PHP7\Result\ResultModel;

class PromotionsService
{
    use LoggerAwareTrait;
    use LoggerTrait;

    /**
     * @var EntityManagerInterface|EntityManager
     */
    private $entityManager;
    /**
     * @var PromotionsRepository
     */
    private $promotionsRepository;

    /**
     * PromotionsService constructor.
     * @param LoggerInterface $logger
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(
        LoggerInterface $logger,
        EntityManagerInterface $entityManager
    )
    {
        $this->setLogger($logger);
        $this->setEntityManager($entityManager);
        $this->getPromotionsRepository();
    }

    /**
     * @return PromotionsRepository
     */
    protected function getPromotionsRepository(): PromotionsRepository
    {
        if (!isset($this->promotionsRepository)) {
            $this->setPromotionsRepository();
        }
        return $this->promotionsRepository;
    }

    /**
     * @param PromotionsRepository|null $promotionsRepository
     */
    public function setPromotionsRepository(?PromotionsRepository $promotionsRepository = null): void
    {
        if (!$promotionsRepository instanceof PromotionsRepository) {
            $promotionsClassMetaData = new ClassMetadata(Promotions::class);
            $promotionsRepository = new PromotionsRepository(
                $this->entityManager,
                $promotionsClassMetaData,
                $this->logger
            );
            $promotionsRepository->setLogger($this->logger);
        }
        $this->promotionsRepository = $promotionsRepository;
    }

    /**
     * @param int $promotionId
     * @param int $productId
     * @return ResultModel
     */
    public function addProductAssociation(int $promotionId, int $productId): ResultModel
    {
        $resultModel = new ResultModel();
        $resultModel->setIsSuccess(false);
        if ($productId && $promotionId) {
            $productResponse = $this->promotionsRepository->addPromotionsProductRecord($promotionId, $productId);
            $associationResponse = $this->promotionsRepository->addPromotionsRebateAssociationsRecord($promotionId, $productId);
            if ($productResponse->isSuccess() && $associationResponse->isSuccess()) {
                $resultModel->setIsSuccess(true);
            }
        }
        return $resultModel;
    }

    /**
     * @param int $promotionId
     * @param int $productId
     * @return ResultModel
     */
    public function removeProductAssociation(int $promotionId, int $productId): ResultModel
    {
        $resultModel = new ResultModel();
        $resultModel->setIsSuccess(false);
        if ($productId && $promotionId) {
            $productResponse = $this->promotionsRepository->removePromotionsProductRecord(
                $promotionId,
                $productId
            );
            $associationResponse = $this->promotionsRepository->removePromotionsRebateAssociationsRecord(
                $promotionId,
                $productId
            );
            if ($productResponse->isSuccess() && $associationResponse->isSuccess()) {
                $resultModel->setIsSuccess(true);
            }
        }
        return $resultModel;
    }

    /**
     * @param int $promotionId
     * @return ResultModel
     * @throws \Exception
     */
    public function validatePromotion(int $promotionId)
    {
        return $this->promotionsRepository->validatePromotion($promotionId);
    }

    /**
     * @return EntityManager|EntityManagerInterface
     */
    protected function getEntityManager()
    {
        return $this->entityManager;
    }

    /**
     * @param EntityManager|EntityManagerInterface $entityManager
     */
    public function setEntityManager($entityManager): void
    {
        $this->entityManager = $entityManager;
    }

    /**
     * Logs with an arbitrary level.
     *
     * @param mixed $level
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    protected function log($level, $message, array $context = array())
    {
        $this->logger->log($level, $message, $context);
    }
}
