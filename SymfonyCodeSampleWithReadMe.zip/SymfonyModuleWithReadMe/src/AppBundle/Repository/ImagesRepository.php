<?php

namespace AppBundle\Repository;

use Doctrine\ORM\NonUniqueResultException;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\LoggerTrait;

/**
 * ImagesRepository */
class ImagesRepository extends \Doctrine\ORM\EntityRepository
{
    use LoggerAwareTrait;
    use LoggerTrait;

    /**
     * @return int
     */
    public function getNextId(): int
    {
        try {
            $em = $this->getEntityManager();
            $highestId = $em->createQueryBuilder()
                ->select('MAX(i.id) + 1')
                ->from('AppBundle:Images', 'i')
                ->getQuery()
                ->getSingleScalarResult();
        } catch (NonUniqueResultException $e) {
            // This exception should never happen, but log it in case it does.
            $this->error(
                __METHOD__ . '/Exception: ' . $e->getMessage()
            );
            $highestId = 0;
        }

        return $highestId;
    }

    /**
     * Logs with an arbitrary level.
     *
     * @param mixed $level
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function log($level, $message, array $context = array())
    {
        $this->logger->log($level, $message, $context);
    }
}
