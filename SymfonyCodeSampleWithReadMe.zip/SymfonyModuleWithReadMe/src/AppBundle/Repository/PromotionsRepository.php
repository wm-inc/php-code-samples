<?php

namespace AppBundle\Repository;

use AppBundle\Entity\Categories;
use AppBundle\Entity\Manufacturers;
use AppBundle\Entity\ManufacturersProductsLines;
use AppBundle\Entity\Products;
use AppBundle\Entity\ProductSubTypes;
use AppBundle\Entity\Promotions;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\ConnectionException;
use Doctrine\DBAL\DBALException;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\Mapping;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\LoggerInterface;
use Psr\Log\LoggerTrait;
use Common\PHP7\Result\ResultModel;

/**
 * PromotionsRepository */
class PromotionsRepository extends \Doctrine\ORM\EntityRepository
{
    use LoggerAwareTrait;
    use LoggerTrait;

    public function __construct(EntityManagerInterface $entityManager, Mapping\ClassMetadata $class)
    {
        parent::__construct($entityManager, $class);
    }

    /**
     * @return int
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public function getNextId(): int
    {
        $em = $this->getEntityManager();
        $highestId = $em->createQueryBuilder()
            ->select('MAX(i.id) + 1')
            ->from('AppBundle:Promotions', 'i')
            ->getQuery()
            ->getSingleScalarResult();
        return $highestId;
    }

    /**
     * Saves records into promotions_rebate_associations.
     * This is done to allow frontend and backend promotions to continue operating correctly without code changes.
     * @param Promotions $promotion
     */
    public function saveLegacyPromotionProductAssociations(Promotions $promotion)
    {
        $manufacturers = $promotion->getManufacturers();
        $this->replaceManufacturerPromotionRebateAssociations($promotion, $manufacturers, 0);

        $excludeManufacturers = $promotion->getExcludeManufacturers();
        $this->replaceManufacturerPromotionRebateAssociations($promotion, $excludeManufacturers, 1);

        $productSubTypes = $promotion->getProductSubTypes();
        $this->replaceProductSubTypePromotionRebateAssociations($promotion, $productSubTypes, 0);

        $excludeProductSubTypes = $promotion->getExcludeProductSubTypes();
        $this->replaceProductSubTypePromotionRebateAssociations($promotion, $excludeProductSubTypes, 1);

        $categories = $promotion->getCategories();
        $this->replaceCategoriesPromotionRebateAssociations($promotion, $categories, 0);

        $excludeCategories = $promotion->getExcludeCategories();
        $this->replaceCategoriesPromotionRebateAssociations($promotion, $excludeCategories, 1);

        $productLines = $promotion->getProductLines();
        $this->replaceProductLinePromotionRebateAssociations($promotion, $productLines, 0); 

        $excludeProductLines = $promotion->getExcludeProductLines();
        $this->replaceProductLinePromotionRebateAssociations($promotion, $excludeProductLines, 1);

        $excludeProducts = $promotion->getExcludeProducts();
        $this->replaceProductPromotionRebateAssociations($promotion, $excludeProducts, 1);
    }

    /**
     * @param Promotions $promotion
     * @param Collection $collection
     */
    protected function replaceManufacturerPromotionRebateAssociations(Promotions $promotion, Collection $collection, $exclude = 0)
    {
        $values = [];
        $promotionId = $promotion->getId();
        /**
         * @var Manufacturers $manufacturer
         */
        foreach ($collection as $manufacturer) {
            $values[] = $manufacturer->getId();
        }

        $this->replacePromotionRebateAssociations($promotionId, 'my_manufacturers', $values, $exclude);
    }

    /**
     * @param Promotions $promotion
     * @param Collection $collection
     */
    protected function replaceProductSubTypePromotionRebateAssociations(Promotions $promotion, Collection $collection, $exclude = 0)
    {
        $values = [];
        $promotionId = $promotion->getId();
        /**
         * @var ProductSubTypes $productSubType
         */
        foreach ($collection as $productSubType) {
            $values[] = $productSubType->getId();
        }

        $this->replacePromotionRebateAssociations($promotionId, 'my_product_sub_types', $values, $exclude);
    }

    /**
     * @param Promotions $promotion
     * @param Collection $collection
     */
    protected function replaceCategoriesPromotionRebateAssociations(Promotions $promotion, Collection $collection, $exclude = 0)
    {
        $values = [];
        $promotionId = $promotion->getId();
        /**
         * @var Categories $category
         */
        foreach ($collection as $category) {
            $values[] = $category->getId();
        }

        $this->replacePromotionRebateAssociations($promotionId, 'my_categories', $values, $exclude);
    }

    /**
     * @param Promotions $promotion
     * @param Collection $collection
     */
    protected function replaceProductLinePromotionRebateAssociations(Promotions $promotion, Collection $collection, $exclude = 0)
    {
        $values = [];
        $promotionId = $promotion->getId();
        /**
         * @var ManufacturersProductsLines $productLines
         */
        foreach ($collection as $productLines) {
            $values[] = $productLines->getId();
        }

        $this->replacePromotionRebateAssociations($promotionId, 'my_manufacturers_products_lines', $values, $exclude);
    }

    /**
     * @param Promotions $promotion
     * @param Collection $collection
     */
    protected function replaceProductPromotionRebateAssociations(Promotions $promotion, Collection $collection, $exclude = 0)
    {
        $values = [];
        $promotionId = $promotion->getId();
        /**
         * @var Products $product
         */
        foreach ($collection as $product) {
            $values[] = $product->getId();
        }

        $this->replacePromotionRebateAssociations($promotionId, 'my_products', $values, $exclude);
    }

    /**
     * Delete existing promotion_rebate_association records and add new records.
     * @param int $promotionId
     * @param string $refTable
     * @param array $values
     */
    protected function replacePromotionRebateAssociations(int $promotionId, string $refTable, array $values, $exclude = 0)
    {
        $dbConnection = $this->getEntityManager()->getConnection();
        try {
            $dbConnection->beginTransaction();
            // Delete existing association records.
            $statement = $dbConnection->prepare(
                'DELETE FROM promotions_rebate_associations WHERE ref_table = :refTable AND promotion_id = :promotionId AND exclude = :exclude'
            );
            $statement->bindValue('refTable', $refTable);
            $statement->bindValue('promotionId', $promotionId);
            $statement->bindValue('exclude', $exclude);
            $statement->execute();

            // Add new association records.
            if (!empty($values)) {
                $sqlStatements = [];
                $sql = 'INSERT INTO promotions_rebate_associations (created, promotion_id, ref_table, ref_id, exclude) VALUES ';
                foreach ($values as $value) {
                    $sqlStatements[] = "(NOW(), {$promotionId}, '{$refTable}', {$value}, {$exclude})";
                }
                $sql .= implode(', ', $sqlStatements);
                
                $dbConnection->query($sql);
            }
            // Commit the delete and insert record transaction.
            $dbConnection->commit();
        } catch (DBALException $e) {
            $this->error(
                __METHOD__ . '/Exception: ' . $e->getMessage()
            );
            try {
                // Rollback both the delete and insert statements if something fails.
                $dbConnection->rollBack();
            } catch (ConnectionException $e) {
                $this->error(
                    __METHOD__ . '/Exception: ' . $e->getMessage()
                );
            }
        }
    }

    /**
     * Logs with an arbitrary level.
     *
     * @param mixed $level
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    protected function log($level, $message, array $context = array())
    {
        $this->logger->log($level, $message, $context);
    }

    /**
     * @param int $promotionId
     * @param int $productId
     * @return ResultModel
     */
    public function addPromotionsProductRecord(int $promotionId, int $productId): ResultModel
    {
        $resultModel = new ResultModel();
        try {
            /**
             * @var Connection
             */
            $dbConnection = $this->getEntityManager()->getConnection();
            $sql = 'INSERT INTO promotions_products (promotion_id, product_id) VALUES (:promotionId, :productId)';
            $statement = $dbConnection->prepare($sql);
            $statement->bindParam('promotionId', $promotionId);
            $statement->bindParam('productId', $productId);
            $isSuccess = $statement->execute();
            if (empty($isSuccess)) {
                $isSuccess = false;
            }
        } catch (DBALException $e) {
            $errorMessage = __METHOD__ . '/Exception: ' . $e->getMessage();
            $this->error($errorMessage);
            $isSuccess = false;
            $resultModel->setErrorMessages([$errorMessage]);
        }
        $resultModel->setIsSuccess($isSuccess);
        return $resultModel;
    }

    /**
     * @param int $promotionId
     * @param int $productId
     * @return ResultModel
     */
    public function addPromotionsRebateAssociationsRecord(int $promotionId, int $productId): ResultModel
    {
        $resultModel = new ResultModel();
        try {
            /**
             * @var Connection
             */
            $dbConnection = $this->getEntityManager()->getConnection();
            $sql = 'INSERT INTO promotions_rebate_associations
                (created, promotion_id, ref_table_id, ref_table, ref_id)
                VALUES (NOW(), :promotionId, 1, \'my_products\', :productId)';
            $statement = $dbConnection->prepare($sql);
            //$promotionId = $this->getPromotionId();
            $statement->bindParam('promotionId', $promotionId);
            $statement->bindParam('productId', $productId);
            $isSuccess = $statement->execute();
            if (empty($isSuccess)) {
                $isSuccess = false;
            }
        } catch (DBALException $e) {
            $errorMessage = __METHOD__ . '/Exception: ' . $e->getMessage();
            $this->error($errorMessage);
            $isSuccess = false;
            $resultModel->setErrorMessages([$errorMessage]);
        }
        $resultModel->setIsSuccess($isSuccess);
        return $resultModel;
    }

    /**
     * @param int $promotionId
     * @return ResultModel
     * @throws \Doctrine\ORM\NoResultException
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public function validatePromotion(int $promotionId)
    {
        $resultModel = new ResultModel();
        $isSuccess = false;
        $promotion = null;
        $errors = [];
        // Validate promotion exists
        if (!$promotionId) {
            $errors[] = "Promotion ID '{$promotionId} not found";
        }

        $date = new \DateTime();
        $date->setTimezone(new \DateTimeZone('UTC'));
        $endDate = $date->format('Y-m-d');
        $queryBuilder = $this->createQueryBuilder('p');
        $queryBuilder
            ->where($queryBuilder->expr()->eq('p.id', $promotionId))
            ->andWhere($queryBuilder->expr()->eq('p.linkTo', ':Products'))
            ->andWhere($queryBuilder->expr()->gt('p.ends', ':ends'))
            ->setParameter(':ends', $endDate)
            ->setParameter(':Products', 'Products');
        try {
            $promotion = $queryBuilder->getQuery()->getSingleResult();
        } catch (\Exception $exception) {
            $errors[] = $exception->getMessage();
        }

        if (empty($promotion)) {
            $errors[] = "Invalid Promotion ID #{$promotionId}, <br> " .
                'Possible Causes: Promotion Not found, Expired, or not linked to products';
            $resultModel->setErrorMessages($errors);
        } else {
            $isSuccess = true;
            $resultModel->setReturnValue($promotion);
        }
        $resultModel->setIsSuccess($isSuccess);
        return $resultModel;
    }

    /**
     * @param int $promotionId
     * @param int $productId
     * @return ResultModel
     */
    public function removePromotionsProductRecord(int $promotionId, int $productId): ResultModel
    {
        $resultModel = new ResultModel();
        $isSuccess = false;
        try {
            $dbConnection = $this->getEntityManager()->getConnection();
            $statement = $dbConnection->prepare('DELETE FROM promotions_products WHERE product_id = :productId AND promotion_id = :promotionId');
            $statement->bindValue('productId', $productId);
            $statement->bindValue('promotionId', $promotionId);
            $statement->execute();
            if ($statement->rowCount()) {
                $isSuccess = true;
            }
        } catch (DBALException $e) {
            $errorMessage = __METHOD__ . '/Exception: ' . $e->getMessage();
            $this->error($errorMessage);
            $isSuccess = false;
            $resultModel->setErrorMessages([$errorMessage]);
        }
        $resultModel->setIsSuccess($isSuccess);
        return $resultModel;
    }

    /**
     * @param int $promotionId
     * @param int $productId
     * @return ResultModel
     */
    public function removePromotionsRebateAssociationsRecord(int $promotionId, int $productId): ResultModel
    {
        $resultModel = new ResultModel();
        $isSuccess = false;
        try {
            $dbConnection = $this->getEntityManager()->getConnection();
            $statement = $dbConnection->prepare('DELETE FROM promotions_rebate_associations WHERE ref_id=:productId and ref_table_id=1 AND promotion_id=:promotionId');
            $statement->bindValue('productId', $productId);
            $statement->bindValue('promotionId', $promotionId);
            $statement->execute();
            if ($statement->rowCount()) {
                $isSuccess = true;
            }
        } catch (DBALException $e) {
            $errorMessage = __METHOD__ . '/Exception: ' . $e->getMessage();
            $this->error($errorMessage);
            $isSuccess = false;
            $resultModel->setErrorMessages([$errorMessage]);
        }
        $resultModel->setIsSuccess($isSuccess);
        return $resultModel;
    }

    /**
     * getPromotionProductsCount
     * @param  string|null $promotionId
     * @return int
     */
    public function getPromotionProductsCount(string $promotionId=null):int
    {
        $dbConnection = $this->getEntityManager()->getConnection();
        $statement = "select COUNT(id) count FROM promotions_products 
                    WHERE promotion_id =$promotionId ";
        $sth = $dbConnection->query( $statement);
        $data= $sth->fetchAll( \PDO::FETCH_ASSOC );
        return  (int)$data[0]['count'];
    }
}
