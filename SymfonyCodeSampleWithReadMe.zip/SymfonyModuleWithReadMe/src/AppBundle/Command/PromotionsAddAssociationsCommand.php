<?php

namespace AppBundle\Command;

use AppBundle\Service\PromotionsService;
use Box\Spout\Common\Type;
use Box\Spout\Reader\ReaderFactory;
use Box\Spout\Reader\SheetInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\LoggerInterface;
use Psr\Log\LoggerTrait;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Stopwatch\Stopwatch;

class PromotionsAddAssociationsCommand extends ContainerAwareCommand
{
    use LoggerAwareTrait;
    use LoggerTrait;

    const COLUMN_PRODUCT_ID = 1;

    protected static $defaultName = 'webmatrixcorp:promotions:add-associations';

    /**
     * @var PromotionsService
     */
    private $promotionsService;

    /**
     * webmatrixcorpPromotionsAddAssociationsCommand constructor.
     * @param PromotionsService $promotionService
     * @param string|null $name
     * @param LoggerInterface|null $logger
     */
    public function __construct(
        PromotionsService $promotionService,
        ?string $name = null,
        LoggerInterface $logger = null
    ) {
        parent::__construct($name);
        $this->setLogger($logger);
        $this->setPromotionsService($promotionService);
    }

    /**
     * @return PromotionsService
     */
    public function getPromotionsService()
    {
        return $this->promotionsService;
    }

    /**
     * @param PromotionsService $promotionsService
     */
    public function setPromotionsService(PromotionsService $promotionsService)
    {
        $this->promotionsService = $promotionsService;
    }

    protected function configure()
    {
        $this
            ->setDescription('Processes a CSV to associate products with a promotion')
            ->addArgument(
                'promotion-id',
                InputArgument::REQUIRED,
                'ID of the promotion which the products will be associated with'
            )
            ->addArgument(
                'filename',
                InputArgument::REQUIRED,
                'Name (including full path) of CSV file containing the products to be associated with the promotion'
            )
            ->addOption(
                'dry-run',
                'd',
                InputOption::VALUE_NONE,
                'Show the data to be associated but do not save it'
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        // Get a stop watch for timing the process.
        $stopWatch = new Stopwatch();
        $stopWatchName = 'promotion-association';
        $stopWatch->start($stopWatchName);

        $io = new SymfonyStyle($input, $output);
        $io->writeln('Begin processing...');

        $promotionId = $input->getArgument('promotion-id');
        $filename = $input->getArgument('filename');
        try {
            $isDryRun = 1 == $input->getOption('dry-run');
        } catch (\InvalidArgumentException $exception) {
            $isDryRun = false;
        }
        $io->note('Dry-run mode is ' . ($isDryRun ? 'enabled' : 'disabled'));
        $rowCount = 0;
        try {
            $resultModel = $this->promotionsService->validatePromotion($promotionId);
            if ($resultModel->isSuccess()) {
                $promotion = $resultModel->getReturnValue();
                $io->comment("Found promotion ({$promotionId}) '{$promotion->getTitle()}'");
                $columnProductId = self::COLUMN_PRODUCT_ID;
                $reader = ReaderFactory::create(Type::CSV);
                $reader->open($filename);
                $io->comment("Found file '{$filename}'");
                /**
                 * @var SheetInterface $sheet
                 */
                $sheet = $reader->getSheetIterator()->current();
                $rowIterator = $sheet->getRowIterator();
                $isHeaderRow = true;
                foreach ($rowIterator as $row) {
                    if ($isHeaderRow) {
                        $isHeaderRow = false;
                        continue;
                    }
                    $productId = (int)$row[$columnProductId - 1];
                    if (!$isDryRun) {
                        $resultModel = $this->promotionsService->addProductAssociation($promotionId, $productId);
                        $isSuccess = $resultModel->isSuccess();
                    } else {
                        $isSuccess = true;
                    }
                    if ($isSuccess) {
                        $rowCount++;
                        $io->write('.');
                    } else {
                        $io->error("Failed associating product ID {$productId}!");
                    }
                }
                $reader->close();
                $io->success('Finished associating products to promotion');
            } else {
                $errorMessages = $resultModel->getErrorMessages();
                $io->note("Errors:\n" . implode("\n", $errorMessages));
            }
        } catch (\Exception $exception) {
            $io->error($exception->getMessage());
            $this->error($exception->getMessage());
            $this->error($exception->getTraceAsString());
        }

        $event = $stopWatch->stop($stopWatchName);
        $duration = $event->getDuration() / 1000;
        $io->comment(
            "Process statistics:" . PHP_EOL . "Rows processed: {$rowCount}" .
            PHP_EOL . "Duration: {$duration} seconds"
        );
    }

    /**
     * Logs with an arbitrary level.
     *
     * @param mixed $level
     * @param string $message
     * @param array $context
     *
     * @return void
     */
    public function log($level, $message, array $context = array())
    {
        $this->logger->log($level, $message, $context);
    }
}
