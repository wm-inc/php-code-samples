<?php

namespace AppBundle\Controller;

use AppBundle\Service\PromotionsService;
use Box\Spout\Common\Type;
use Box\Spout\Reader\ReaderFactory;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class PromotionBulkAssociationController
 * @package AppBundle\Controller
 * @Route("/marketing/promotion/bulk")
 */
class PromotionBulkAssociationController extends Controller
{
    /**
     * @var PromotionsService
     */
    private $promotionsService;

    public function __construct(PromotionsService $promotionsService)
    {
        $this->setPromotionsService($promotionsService);
    }

    /**
     * @return PromotionsService
     */
    public function getPromotionsService()
    {
        return $this->promotionsService;
    }

    /**
     * @param PromotionsService $promotionsService
     */
    public function setPromotionsService(PromotionsService $promotionsService)
    {
        $this->promotionsService = $promotionsService;
    }

    /**
     * @param $promotionId
     * @param bool $associate
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|\Symfony\Component\HttpFoundation\Response
     * @throws \Exception
     */
    protected function associateProducts($promotionId, bool $associate, Request $request)
    {
        $upform = $this->get('form.factory')->createNamedBuilder('upform')
            ->add('file', FileType::class)
            ->add('upload', SubmitType::class)
            ->getForm();

        $upform->handleRequest($request);
        $resultModel = $this->promotionsService->validatePromotion($promotionId);

        if (!$resultModel->isSuccess()) {
            $errors = $resultModel->getErrorMessages();
            $this->addFlash('error', implode(",<br> ", $errors));
        }
        $formProcess = ($associate) ? "Associate" : "Disassociate";

        if ($request->request->has('upform')) {
            $form_data = $upform->getData();
            if ($resultModel->isSuccess()) {
                try {
                    $rowCount = 0;
                    $successCount = 0;
                    $unsuccessfulProducts = [];
                    $filename = $form_data['file']->getPathname();
                    $reader = ReaderFactory::create(Type::CSV);
                    $reader->open($filename);
                    $sheet = $reader->getSheetIterator()->current();
                    $rowIterator = $sheet->getRowIterator();
                    $isHeaderRow = true;
                    foreach ($rowIterator as $row) {
                        if ($isHeaderRow) {
                            $isHeaderRow = false;
                            continue;
                        }
                        $rowCount++;
                        $productId = (int)$row[0];
                        if ($associate) {
                            $resultModel = $this->promotionsService->addProductAssociation($promotionId, $productId);
                        } else {
                            $resultModel = $this->promotionsService->removeProductAssociation($promotionId, $productId);
                        }
                        if ($resultModel->isSuccess()) {
                            $successCount++;
                        } else {
                            $unsuccessfulProducts[] = $productId;
                        }
                    }
                    $reader->close();

                    $message = "{$successCount} out of {$rowCount} products successfully  {$formProcess}d to " .
                        "Promotion ID {$promotionId}.<br>";
                    if ($unsuccessfulProducts) {
                        $message .= 'The following products were not successfully associated:<br>' .
                            implode(', ', $unsuccessfulProducts);
                    }
                    $this->addFlash('success', $message);
                    return $this->redirectToRoute(
                        'admin_promotion_list'
                    );
                } catch (\Exception $exception) {
                    $upform->get('file')->addError($exception->getMessage());
                }
            } else {
                $errors = $resultModel->getErrorMessages();
                $upform->get('file')->addError(new FormError(implode(', ', $errors)));
                unset($form_data);
            }
        }
        return $this->render('AppBundle::promotionAssociation.html.twig', array(
            'upform' => $upform->createView(),
            'formProcess' => $formProcess,
            'promotionId' => $promotionId
        ));
    }

    /**
     * @Route("/product-associations/{promotionId}", name="app.promotion.bulk.product-associations")
     * @param $promotionId
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function bulkProductAssociationAction($promotionId, Request $request)
    {
        return $this->associateProducts($promotionId, true, $request);
    }

    /**
     * @Route("/product-disassociations/{promotionId}", name="app.promotion.bulk.product-disassociations")
     * @param $promotionId
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function bulkProductDisAssociationAction($promotionId, Request $request)
    {
        return $this->associateProducts($promotionId, false, $request);
    }
}