<?php

namespace Tests\AppBundle\Service;

use AppBundle\Repository\PromotionsRepository;
use AppBundle\Service\PromotionsService;
use Doctrine\ORM\EntityManagerInterface;
use Monolog\Logger;
use Psr\Log\LoggerInterface;
use Psr\Log\LoggerAwareTrait;
use Psr\Log\LoggerTrait;

class PromotionsServiceTestStub extends PromotionsService
{
    public function __construct(LoggerInterface $logger, EntityManagerInterface $entityManager)
    {
        parent::__construct($logger, $entityManager);
    }

    public function getEntityManager()
    {
        return parent::getEntityManager();
    }

    public function getPromotionsRepository(): PromotionsRepository
    {
        return parent::getPromotionsRepository();
    }
}