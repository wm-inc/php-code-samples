<?php

namespace Tests\AppBundle\Service;
use AppBundle\Service\PromotionsService;
use Common\PHP7\Result\ResultModel;
use AppBundle\Repository\PromotionsRepository;
use Doctrine\ORM\EntityManager;
use PHPUnit\Framework\TestCase;
use Monolog\Logger;

class promotionsServiceUnitTest extends TestCase
{
    /**
     * @var PromotionsServiceTestStub
     */
    private $promotionsService;

    /**
     * @var EntityManager|\Phake_IMock
     */
    private $entityManager;

    /**
     * @var promotionsRepository|\Phake_IMock
     */
    private $promotionsRepository;

    public function setUp()
    {
        parent::setUp();
        $this->entityManager = \Phake::mock(EntityManager::class);
        $this->logger = \Phake::mock(Logger::class);
        $this->promotionsService = new PromotionsServiceTestStub($this->logger, $this->entityManager);
        $this->hasPromotionsRepository();
    }

    public function tearDown()
    {
        unset($this->promotionsService);
        parent::tearDown();
    }

    public function testEntityManagerGetterAndSetter()
    {
        $this->promotionsService->setEntityManager($this->entityManager);
        $actualEntityManager = $this->promotionsService->getEntityManager();
        $this->assertInstanceOf(EntityManager::class, $actualEntityManager);
        $this->assertInstanceOf(\Phake_IMock::class, $actualEntityManager);
        $this->assertSame($this->entityManager, $actualEntityManager);
    }

    public function testConstruct()
    {
        $actualEntityManager = $this->promotionsService->getEntityManager();
        $this->assertInstanceOf(EntityManager::class, $actualEntityManager);
        $this->assertInstanceOf(\Phake_IMock::class, $actualEntityManager);
        $this->assertSame($this->entityManager, $actualEntityManager);
    }

    public function testSetPromtionsRepositoryWhenParameterIsNullReturnsNewRepository()
    {
        $this->promotionsService->setPromotionsRepository();
        $actualRepository = $this->promotionsService->getPromotionsRepository();
        $this->assertInstanceOf(PromotionsRepository::class, $actualRepository);
        $this->assertNotInstanceOf(\Phake_IMock::class, $actualRepository);
    }

    public function testPromotionsRepositoryGetterAndSetterWhenParameterIsSuppliedReturnsSuppliedParameter()
    {
        $this->promotionsService->setPromotionsRepository($this->promotionsRepository);
        $actualPromotionsRepository = $this->promotionsService->getPromotionsRepository();
        $this->assertInstanceOf(PromotionsRepository::class, $actualPromotionsRepository);
        $this->assertInstanceOf(\Phake_IMock::class, $actualPromotionsRepository);
        $this->assertSame($this->promotionsRepository, $actualPromotionsRepository);
    }

    /**
     * @param array $returnArray
     */
    private function hasPromotionsRepository($returnArray = [])
    {
        $this->promotionsRepository = \Phake::mock(PromotionsRepository::class);
        \Phake::when($this->promotionsRepository)->findBy(\Phake::anyParameters())
            ->thenReturn($returnArray);
        $this->promotionsService->setpromotionsRepository($this->promotionsRepository);
    }

    public function testAddProductAssociationWhenPromtionIsNotValid()
    {
        $productResponse = \Phake::mock(ResultModel::class);
        $productResponse->setIsSuccess(false);
        $associationResponse = \Phake::mock(ResultModel::class);
        $associationResponse->setIsSuccess(false);

        \Phake::when($this->promotionsRepository)->addPromotionsProductRecord(\Phake::anyParameters())
            ->thenReturn($productResponse);
        \Phake::when($this->promotionsRepository)->addPromotionsRebateAssociationsRecord(\Phake::anyParameters())
            ->thenReturn($associationResponse);
        $this->promotionsService->addProductAssociation(1, 1);
        \Phake::verify($this->promotionsRepository, \Phake::times(1))->addPromotionsProductRecord(1, 1);
        \Phake::verify($this->promotionsRepository, \Phake::times(1))->addPromotionsRebateAssociationsRecord(1, 1);
    }

    public function testAddProductAssociationWhenPromtionIsValid()
    {

        $resultModel = \Phake::mock(ResultModel::class);
        $productResponse = \Phake::mock(ResultModel::class);
        $associationResponse = \Phake::mock(ResultModel::class);

        \Phake::when($resultModel)->setIsSuccess(false)->thenReturn(false);
        \Phake::when($resultModel)->setIsSuccess(true)->thenReturn(true);
        \Phake::when($productResponse)->setIsSuccess(\Phake::anyParameters())->thenReturn(true);
        \Phake::when($associationResponse)->setIsSuccess(\Phake::anyParameters())->thenReturn(true);

        \Phake::when($resultModel)->isSuccess()->thenReturn(true);
        \Phake::when($productResponse)->isSuccess()->thenReturn(true);
        \Phake::when($associationResponse)->isSuccess()->thenReturn(true);


        \Phake::when($this->promotionsRepository)->addPromotionsProductRecord(
            \Phake::anyParameters()
        )->thenReturn($productResponse);

        \Phake::when($this->promotionsRepository)->addPromotionsRebateAssociationsRecord(
            \Phake::anyParameters()
        )->thenReturn($associationResponse);

        $this->promotionsService->addProductAssociation(1, 1);

        $resultModel->setIsSuccess(false);
        $resultModel->setIsSuccess(true);
        $productResponse->setIsSuccess(true);
        $associationResponse->setIsSuccess(true);

        $resultModel->isSuccess();
        $productResponse->isSuccess();

        \Phake::verify(
            $this->promotionsRepository,
            \Phake::times(1)
        )->addPromotionsProductRecord(1, 1);

        \Phake::verify(
            $this->promotionsRepository,
            \Phake::times(1)
        )->addPromotionsRebateAssociationsRecord(1, 1);

        \Phake::verify($associationResponse, \Phake::times(1))->isSuccess();
        \Phake::verify($resultModel, \Phake::times(1))->setIsSuccess(true);
    }

    public function testValidatePromotion()
    {
        $resultModel = \Phake::mock(ResultModel::class);
        $this->promotionsService->validatePromotion(1);
        \Phake::when($this->promotionsRepository)->validatePromotion(1)->thenReturn($resultModel);
        \Phake::verify($this->promotionsRepository, \Phake::times(1))->validatePromotion(1);
    }


    public function testRemoveProductAssociationWhenPromtionIsValid()
    {
        $resultModel = \Phake::mock(ResultModel::class);
        $productResponse = \Phake::mock(ResultModel::class);
        $associationResponse = \Phake::mock(ResultModel::class);

        \Phake::when($resultModel)->setIsSuccess(false)->thenReturn(false);
        \Phake::when($resultModel)->setIsSuccess(true)->thenReturn(true);
        \Phake::when($productResponse)->setIsSuccess(\Phake::anyParameters())->thenReturn(true);
        \Phake::when($associationResponse)->setIsSuccess(\Phake::anyParameters())->thenReturn(true);

        \Phake::when($resultModel)->isSuccess()->thenReturn(true);
        \Phake::when($productResponse)->isSuccess()->thenReturn(true);
        \Phake::when($associationResponse)->isSuccess()->thenReturn(true);


        \Phake::when($this->promotionsRepository)->removePromotionsProductRecord(
            \Phake::anyParameters()
        )->thenReturn($productResponse);

        \Phake::when($this->promotionsRepository)->removePromotionsRebateAssociationsRecord(
            \Phake::anyParameters()
        )->thenReturn($associationResponse);

        $this->promotionsService->removeProductAssociation(1, 1);

        $resultModel->setIsSuccess(false);
        $resultModel->setIsSuccess(true);
        $productResponse->setIsSuccess(true);
        $associationResponse->setIsSuccess(true);

        $resultModel->isSuccess();
        $productResponse->isSuccess();

        \Phake::verify(
            $this->promotionsRepository,
            \Phake::times(1)
        )->removePromotionsProductRecord(1, 1);

        \Phake::verify(
            $this->promotionsRepository,
            \Phake::times(1)
        )->removePromotionsRebateAssociationsRecord(1, 1);

        \Phake::verify($associationResponse, \Phake::times(1))->isSuccess();
        \Phake::verify($resultModel, \Phake::times(1))->setIsSuccess(true);
    }

    public function testRemoveProductAssociationWhenPromtionIsNotValid()
    {
        $productResponse = \Phake::mock(ResultModel::class);
        $productResponse->setIsSuccess(false);
        $associationResponse = \Phake::mock(ResultModel::class);
        $associationResponse->setIsSuccess(false);

        \Phake::when($this->promotionsRepository)->removePromotionsProductRecord(\Phake::anyParameters())
            ->thenReturn($productResponse);
        \Phake::when($this->promotionsRepository)->removePromotionsRebateAssociationsRecord(\Phake::anyParameters())
            ->thenReturn($associationResponse);
        $this->promotionsService->removeProductAssociation(1, 1);
        \Phake::verify($this->promotionsRepository, \Phake::times(1))->removePromotionsProductRecord(1, 1);
        \Phake::verify($this->promotionsRepository, \Phake::times(1))->removePromotionsRebateAssociationsRecord(1, 1);
    }
}
