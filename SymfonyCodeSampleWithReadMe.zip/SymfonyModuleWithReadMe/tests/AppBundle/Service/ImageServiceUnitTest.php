<?php

namespace Tests\AppBundle\Service;

use AppBundle\Service\ImageService;
use AppBundle\Service\S3ClientFactory;
use AppBundle\Service\ContentDeliveryNetwork\CdnProviderFactory;
use Monolog\Logger;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\Filesystem\Filesystem;
use Common\PHP7\Tests\UnitTestProviderTrait;

/**
 * Class ImageServiceUnitTest
 * @package Tests\AppBundle\Service
 */
class ImageServiceUnitTest extends KernelTestCase
{
    const VALID_IMAGE = "web/tmp/ValidGroupImageForUnitTest.jpg";
    const INVALID_IMAGE = "web/tmp/InvalidGroupImageForUnitTest.jpg";

    use UnitTestProviderTrait;

    /**
     * @var ImageService
     */
    private $imageService;
    /**
     * @var S3ClientFactory
     */
    private $s3ClientFactory;
    /**
     * @var Filesystem
     */
    private $fileSystem;
    /**
     * @var Logger
     */
    private $logger;

    public function setUp()
    {
        parent::setUp();
//        $kernel = self::bootKernel();
//        $this->awsConfig = $kernel->getContainer()->getParameter('aws_config');
        $this->s3ClientFactory = \Phake::mock(S3ClientFactory::class);
        $this->cdnProviderFactory = \Phake::mock(CdnProviderFactory::class);
        $this->fileSystem = \Phake::mock(Filesystem::class);
        \Phake::when($this->fileSystem)->exists(\Phake::anyParameters())
            ->thenReturn(true);
        $this->logger = \Phake::mock(Logger::class);
        $this->imageService =  new ImageService(
            $this->fileSystem,
            $this->logger,
            $this->s3ClientFactory,
            [],
            $this->cdnProviderFactory
        );
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider integerProvider
     */
    public function testHeightGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setHeight($originalValue);
        $actualValue = $this->imageService->getHeight();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider integerProvider
     */
    public function testWidthGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setWidth($originalValue);
        $actualValue = $this->imageService->getWidth();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testAwsConfigGetterAndSetter()
    {
        $this->markTestIncomplete('awsConfig not needed in this class. Use in factory class instead.');
        $originalValue = $this->awsConfig;
        $expectedValue = $this->awsConfig;
        $this->imageService->setAwsConfig($originalValue);
        $actualValue = $this->imageService->getAwsConfig();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider integerProvider
     */
    public function testFileSizeGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setFileSize($originalValue);
        $actualValue = $this->imageService->getFileSize();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider AllowedTypeProvider
     */
    public function testAllowedTypeGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setAllowedType($originalValue);
        $actualValue = $this->imageService->getAllowedType();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     *
     */
    public function testDeleteFromS3()
    {
        $this->markTestIncomplete('S3 images cannot be deleted from unit test.');
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     */
    public function testSaveToS3()
    {
        $this->markTestIncomplete('S3 images cannot be uploaded from unit test.');
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider integerProvider
     */
    public function testMinHeightGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setMinHeight($originalValue);
        $actualValue = $this->imageService->getMinHeight();
        $this->assertEquals($expectedValue, $actualValue);
    }

    public function testResize()
    {
        $expectedValue = true;
        $basepath = $this->getBasePath();
        $this->imageService->setAbsoluteImageSource($basepath.self::VALID_IMAGE);
        $this->imageService->setAbsoluteImageDestination($basepath.self::VALID_IMAGE);
        $this->imageService->setDeleteInvalid(false);
        $actualValue =  $this->imageService->resize(145, 145);
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider qualityProvider
     */
    public function testQualityGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setQuality($originalValue);
        $actualValue = $this->imageService->getQuality();
        $this->assertEquals($expectedValue, $actualValue);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider integerProvider
     */
    public function testMaxWidthGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setMaxWidth($originalValue);
        $actualValue = $this->imageService->getMaxWidth();
        $this->assertEquals($expectedValue, $actualValue);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider booleanProvider
     */
    public function testSuccessGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setSuccess($originalValue);
        $actualValue = $this->imageService->isSuccess();
        $this->assertSame($expectedValue, $actualValue);
    }


    public function testValidateWhenImageIsValid()
    {
        $expectedValue = [];
        $this->setValidImageAttributes();
        $basePath = $this->getBasePath();
        $this->imageService->setAbsoluteImageSource($basePath.self::VALID_IMAGE);
        $this->imageService->setDeleteInvalid(false);
        $actualValue = $this->imageService->validate();
        $this->assertEquals($expectedValue, $actualValue);
    }

    public function testValidateWhenImageIsNotValid()
    {
        $expectedValue = [];
        $basePath = $this->getBasePath();
        $this->setValidImageAttributes();
        $this->imageService->setAbsoluteImageSource($basePath.self::INVALID_IMAGE);
        $this->imageService->setDeleteInvalid(false);
        $actualValue = $this->imageService->validate();
        $this->assertGreaterThan($expectedValue, $actualValue);
    }

    function setValidImageAttributes(){
        $this->imageService->setMinHeight(0);
        $this->imageService->setMinWidth(0);
        $this->imageService->setMaxWidth(220);
        $this->imageService->setFileSize(1000000);
        $this->imageService->setAllowedType(['image/jpeg']);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider integerProvider
     */
    public function testMinWidthGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setMinWidth($originalValue);
        $actualValue = $this->imageService->getMinWidth();
        $this->assertEquals($expectedValue, $actualValue);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider stringProvider
     */
    public function testAbsoluteImageSourceGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setAbsoluteImageSource($originalValue);
        $actualValue = $this->imageService->getAbsoluteImageSource();
        $this->assertEquals($expectedValue, $actualValue);
    }

    /**
     * @param $originalValue
     * @param $expectedValue
     * @dataProvider stringProvider
     */
    public function testAbsoluteImageDestinationGetterAndSetter($originalValue, $expectedValue)
    {
        $this->imageService->setAbsoluteImageDestination($originalValue);
        $actualValue = $this->imageService->getAbsoluteImageDestination();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * array Provider.
     *
     * @return array
     */
    public function allowedTypeProvider()
    {
        return [
            [['png','jpg'],['png','jpg']],
            [['png','jpeg'],['png','jpeg']]
        ];
    }

    /**
     * quality provider
     * @return array
     */
    public function qualityProvider()
    {
        return [
            [0, 0],
            [123, 123],
            [345, 345]
        ];
    }

    /**
     * @return string
     */
    public function getBasePath()
    {
        return dirname(dirname(dirname(__DIR__))).'/';
    }
}
