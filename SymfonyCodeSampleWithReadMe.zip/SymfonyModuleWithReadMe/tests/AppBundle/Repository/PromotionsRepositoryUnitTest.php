<?php

namespace Tests\AppBundle\Repository;

use AppBundle\Repository\PromotionsRepository;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;
use Monolog\Logger;
use Common\PHP7\Result\ResultModel;
use PHPUnit\Framework\TestCase;
use AppBundle\Entity\Promotions;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\EntityManager;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Statement;
use Doctrine\ORM\Mapping\ClassMetadata;

class PromotionsRepositoryUnitTest extends TestCase
{
    /**
     * @var Promotions
     */
    private $promotion;
    /**
     * @var PromotionsRepositoryTestStub
     */
    private $promotionsRepository;
    /**
     * @var entityManager
     */
    private $entityManager;
    /**
     * @var ClassMetadata
     */
    private $classMetadata;
    /**
     * @var Statement
     */
    private $mockStatement;
    /**
     * @var Connection
     */
    private $mockConnection;
    /**
     * @var Logger
     */
    private $mockLogger;

    public function setUp()
    {
        parent::setUp();
        $this->promotion = new Promotions();
        $this->promotion->setId(123);
        $this->mockStatement = \Phake::mock(Statement::class);
        $this->mockConnection = \Phake::mock(Connection::class);
        \Phake::when($this->mockConnection)->prepare(\Phake::anyParameters())
            ->thenReturn($this->mockStatement);
        $this->entityManager = \Phake::mock(EntityManager::class);
        \Phake::when($this->entityManager)->getConnection()
            ->thenReturn($this->mockConnection);
        $this->classMetadata = \Phake::mock(ClassMetadata::class);
        $this->mockLogger = \Phake::mock(Logger::class);
        $this->promotionsRepository = new PromotionsRepositoryTestStub(
            $this->entityManager,
            $this->classMetadata,
            $this->mockLogger
        );
    }

    public function tearDown()
    {
        unset($this->mockLogger);
        unset($this->mockConnection);
        unset($this->mockStatement);
        unset($this->classMetadata);
        unset($this->promotionsRepository);
        unset($this->promotion);
        parent::tearDown();
    }

    public function testSaveLegacyPromotionProductAssociations()
    {
        $mockArrayCollection = new ArrayCollection();
        $this->promotion->setManufacturers($mockArrayCollection);
        $this->promotion->setProductSubTypes($mockArrayCollection);
        $this->promotion->setCategories($mockArrayCollection);
        $this->promotion->setProductLines($mockArrayCollection);
        $this->promotion->setProducts($mockArrayCollection);
        $this->promotion->setExcludeManufacturers($mockArrayCollection);
        $this->promotion->setExcludeProductSubTypes($mockArrayCollection);
        $this->promotion->setExcludeCategories($mockArrayCollection);
        $this->promotion->setExcludeProductLines($mockArrayCollection);
        $this->promotion->setExcludeProducts($mockArrayCollection);
        
        $actualManufacturers = $this->promotion->getManufacturers();
        $this->assertSame($mockArrayCollection, $actualManufacturers);
        $this->promotionsRepository->saveLegacyPromotionProductAssociations($this->promotion);

        $actualManufacturers = $this->promotion->getExcludeManufacturers();
        $this->assertSame($mockArrayCollection, $actualManufacturers);
        $this->promotionsRepository->saveLegacyPromotionProductAssociations($this->promotion);

        $actualProductSubTypes = $this->promotion->getProductSubTypes();
        $this->assertSame($mockArrayCollection, $actualProductSubTypes);

        $actualProductSubTypes = $this->promotion->getExcludeProductSubTypes();
        $this->assertSame($mockArrayCollection, $actualProductSubTypes);
        
        $actualCategories = $this->promotion->getCategories();
        $this->assertSame($mockArrayCollection, $actualCategories);

        $actualCategories = $this->promotion->getExcludeCategories();
        $this->assertSame($mockArrayCollection, $actualCategories);

        $actualProductLine = $this->promotion->getProductLines();
        $this->assertSame($mockArrayCollection, $actualProductLine);

        $actualProductLine = $this->promotion->getExcludeProductLines();
        $this->assertSame($mockArrayCollection, $actualProductLine);

        $actualProducts = $this->promotion->getProducts();
        $this->assertSame($mockArrayCollection, $actualProducts);

        $actualProducts = $this->promotion->getExcludeProducts();
        $this->assertSame($mockArrayCollection, $actualProducts);
    }
    
    public function testReplacePromotionRebateAssociationsWhenValuesEmpty()
    {
        $promotionId = 1;
        $exclude = 0;
        $refTable = 'abc';
        $values = [];

        $this->promotionsRepository->replacePromotionRebateAssociations($promotionId, $refTable, $values, $exclude);

        \Phake::verify($this->mockStatement, \Phake::times(1))->bindValue('refTable', $refTable);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindValue('promotionId', $promotionId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->execute();
        \Phake::verify($this->mockConnection, \Phake::times(0))->query(\Phake::anyParameters());
        \Phake::verify($this->mockConnection, \Phake::times(1))->commit();
    }

    public function testReplacePromotionRebateAssociationsWhenValuesSupplied()
    {
        $promotionId = 1;
        $refTable = 'abc';
        $exclude = 0;
        $values = [1, 2, 3];

        $this->promotionsRepository->replacePromotionRebateAssociations($promotionId, $refTable, $values, $exclude);

        \Phake::verify($this->mockStatement, \Phake::times(1))->bindValue('refTable', $refTable);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindValue('promotionId', $promotionId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->execute();
        \Phake::verify($this->mockConnection, \Phake::times(1))->query(\Phake::anyParameters());
        \Phake::verify($this->mockConnection, \Phake::times(1))->commit();
    }

    public function testAddPromotionsProductRecord()
    {
        $promotionId = 1;
        $productId   = 1;
        $exclude = 0;
        $resultModel = \Phake::mock(ResultModel::class);
        $this->promotionsRepository->addPromotionsProductRecord($promotionId, $productId, $exclude);

        \Phake::verify($this->mockStatement, \Phake::times(1))->bindParam('promotionId', $promotionId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindParam('productId', $productId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->execute();
    }

    public function testAddPromotionsRebateAssociationsRecord()
    {
        $promotionId = 1;
        $productId   = 1;
        $exclude = 0;
        $this->promotionsRepository->addPromotionsRebateAssociationsRecord($promotionId, $productId, $exclude);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindParam('promotionId', $promotionId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindParam('productId', $productId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->execute();
    }


    public function testRemovePromotionsProductRecord()
    {
        $promotionId = 1;
        $productId   = 1;
        $exclude = 0;
        $this->promotionsRepository->removePromotionsProductRecord($promotionId, $productId, $exclude);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindValue('promotionId', $promotionId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindValue('productId', $productId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->execute();
    }

    public function testRemovePromotionsRebateAssociationsRecord()
    {
        $promotionId = 1;
        $productId   = 1;
        $exclude = 0;
        $this->promotionsRepository->removePromotionsRebateAssociationsRecord($promotionId, $productId, $exclude);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindValue('promotionId', $promotionId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->bindValue('productId', $productId);
        \Phake::verify($this->mockStatement, \Phake::times(1))->execute();
    }
}
