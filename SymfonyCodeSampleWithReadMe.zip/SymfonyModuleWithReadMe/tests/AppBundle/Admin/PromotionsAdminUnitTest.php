<?php
/**
 * Created by PhpStorm.
 * User: WMINDIT01
 * Date: 6/18/2018
 * Time: 12:35 AM
 */

namespace Tests\AppBundle\Admin;

use AppBundle\Entity\Images;
use AppBundle\Entity\Promotions;
use AppBundle\Repository\PromotionsRepository;
use AppBundle\Service\ImageService;
use Doctrine\ORM\EntityManager;
use Knp\Menu\ItemInterface as MenuItemInterface;
use Knp\Menu\MenuItem;
use Monolog\Logger;
use PHPUnit\Framework\TestCase;
use Psr\Log\LoggerInterface;
use Slim\Http\Request;
use Sonata\AdminBundle\Admin\AdminInterface;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Route\DefaultRouteGenerator;
use Sonata\AdminBundle\Security\Handler\NoopSecurityHandler;
use Sonata\AdminBundle\Show\ShowMapper;
use Sonata\AdminBundle\Form\Type\ChoiceFieldMaskType;
use Sonata\CoreBundle\Form\Type\DatePickerType;
use Sonata\DoctrineORMAdminBundle\Model\ModelManager;
use Symfony\Component\Form\Extension\Core\Type\FileType;

class PromotionsAdminUnitTest extends TestCase
{
    /**
     * @var PromotionsAdminTestStub
     */
    private $promotionsAdmin;
    /**
     * @var ImageService
     */
    private $imageService;
    /**
     * @var Images
     */
    private $imageEntity;
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var Promotions
     */
    private $promotion;

    public function setUp()
    {
        parent::setUp();
        $this->imageService = \Phake::mock(ImageService::class);
        $this->imageEntity = \Phake::mock(Images::class);
        $this->logger = \Phake::mock(Logger::class);
        $this->promotion = \Phake::mock(Promotions::class);
        $this->promotionsAdmin = new PromotionsAdminTestStub(
            'admin.group',
            'AppBundle\Entity\Promotions',
            'SonataAdminBundle:CRUD',
            $this->imageService,
            $this->imageEntity,
            $this->logger
        );
        $this->promotionsAdmin->setSubject($this->promotion);
    }

    public function tearDown()
    {
        unset($this->promotionsAdmin);
        parent::tearDown();
    }

    public function testBaseRouteSettings()
    {
        $expectedBaseRoutePattern = 'marketing/promotions';
        $actualValue = $this->promotionsAdmin->getBaseRoutePattern();
        $this->assertSame($expectedBaseRoutePattern, $actualValue);

        $expectedBaseRouteName = 'admin_promotion';
        $actualValue = $this->promotionsAdmin->getBaseRouteName();
        $this->assertSame($expectedBaseRouteName, $actualValue);
    }

    /**
     * Test the ConfigureDatagridFilters function.
     */
    public function testConfigureDatagridFilters()
    {
        $mockDataGripMapper = \Phake::mock(DatagridMapper::class);
        \Phake::when($mockDataGripMapper)->add(\Phake::anyParameters())->thenReturn($mockDataGripMapper);
        $this->promotionsAdmin->configureDatagridFilters($mockDataGripMapper);
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('begins');
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('ends');
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('title');
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('shortTitle');
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('subTitle');
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('rebatePrice');
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('rebateText');
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('rebateSubtext');
        \Phake::verify($mockDataGripMapper, \Phake::times(1))->add('teaser');
    }

    /**
     * Test the ConfigureFormFields function.
     */
    public function testConfigureFormFields()
    {
        if (method_exists('Symfony\Component\Form\AbstractType', 'getBlockPrefix')) {
            $datePickerType = 'Sonata\CoreBundle\Form\Type\DatePickerType';
        } else {
            $datePickerType = 'sonata_type_date_picker';
        }
        $mockFormMapper = \Phake::mock(FormMapper::class);
        \Phake::when($mockFormMapper)->add(\Phake::anyParameters())
            ->thenReturn($mockFormMapper);
        \Phake::when($mockFormMapper)->tab(\Phake::anyParameters())
            ->thenReturn($mockFormMapper);
        \Phake::when($mockFormMapper)->with(\Phake::anyParameters())
            ->thenReturn($mockFormMapper);
        \Phake::when($mockFormMapper)->end(\Phake::anyParameters())
            ->thenReturn($mockFormMapper);
        $this->promotionsAdmin->configureFormFields($mockFormMapper);
        \Phake::verify($mockFormMapper, \Phake::times(1))->tab('Promotion');
        \Phake::verify($mockFormMapper, \Phake::times(1))->with('Basic Info', array('class' => 'col-md-7'));
        \Phake::verify($mockFormMapper, \Phake::times(1))->add(
            'title',
            null,
            ['help' => '[Do not use comma (,) in name]']
        );
        //\Phake::verify($mockFormMapper, \Phake::times(1))->add('teaser', null, ['attr' => ['rows' => 6]]);
        \Phake::verify($mockFormMapper, \Phake::times(1))
            ->with('Show on Home/Special Page/Google Feed', array('class' => 'col-md-5'));
        \Phake::verify($mockFormMapper, \Phake::times(1))->add('showOnHomePage', null, [
            'required' =>   false,'label' =>'Include in Promotions featured on the home page'
        ]);
        \Phake::verify($mockFormMapper, \Phake::times(1))->add('showOnSpecialsPage', null, [
            'required' =>   false,'label' =>'Show On Site (Catalog, SKU, Promotion)'
        ]);
        \Phake::verify($mockFormMapper, \Phake::times(1))
            ->add('linkToGoogleFeed', null, ['required' =>   false,'label' =>'Link to Google Feed']);
        \Phake::verify($mockFormMapper, \Phake::times(1))->add('promoType', 'choice', ['choices' => [
            Promotions::PROMOTYPE_REBATE => Promotions::PROMOTYPE_REBATE,
            Promotions::PROMOTYPE_SALE => Promotions::PROMOTYPE_SALE,
            Promotions::PROMOTYPE_OFFER => Promotions::PROMOTYPE_OFFER,
            Promotions::PROMOTYPE_MEMBERS_ONLY => Promotions::PROMOTYPE_MEMBERS_ONLY
        ]]);
        \Phake::verify($mockFormMapper, \Phake::times(1))->add('displayArea', ChoiceFieldMaskType::class, [
                'choices' => [
                    Promotions::DISPLAYAREA_RETAIL => Promotions::DISPLAYAREA_RETAIL,
                    Promotions::DISPLAYAREA_WHOLESALE => Promotions::DISPLAYAREA_WHOLESALE
                ],
                'map' => [
                    Promotions::DISPLAYAREA_RETAIL => '',
                    Promotions::DISPLAYAREA_WHOLESALE => ['wholesale'],
                ],
                'placeholder' => 'Choose an option',
                'required' => true
            ]);
        \Phake::verify($mockFormMapper, \Phake::times(1))->add('wholesale');
        \Phake::verify($mockFormMapper, \Phake::times(1))->tab('Period');
        \Phake::verify($mockFormMapper, \Phake::times(1))->with('From and To ', array('class' => 'col-md-12'));
        \Phake::verify($mockFormMapper, \Phake::times(1))->add('begins', $datePickerType, [
                            'required' => false,
                            'label' => 'Begins'
                        ]);
        \Phake::verify($mockFormMapper, \Phake::times(1))->add('ends', $datePickerType, [
                            'required' => false,
                            'label' => 'Ends'
                        ]);
        \Phake::verify($mockFormMapper, \Phake::times(1))->tab('Images');
        \Phake::verify($mockFormMapper, \Phake::times(1))
            ->with('Rotating images should all have the same dimensions');
//        \Phake::verify($mockFormMapper, \Phake::times(1))
//            ->add('imageHomePageFile', 'file', ['required' => true,'label' =>'Home Page Image']);
//        \Phake::verify($mockFormMapper, \Phake::times(1))
//            ->add('ImageSpecialsPageFile', 'file', ['required' => true,'label' =>'Specials Page Image']);
        \Phake::verify($mockFormMapper, \Phake::times(1))->tab('Link To');
        \Phake::verify($mockFormMapper, \Phake::times(1))->with('Rebate PDF', ['class' => 'col-md-4']);
        $pdfName = '*Requirements: Upload valid Pdf Document';
        \Phake::verify($mockFormMapper, \Phake::times(1))->add('pdfFile', FileType::class, [
            'required' => false,
            'label' => 'PDF',
            'help' => $pdfName,
            'data_class' => null
        ]);

        \Phake::verify($mockFormMapper, \Phake::times(1))->add('linkTo', ChoiceFieldMaskType::class, [
            'choices' => [
                Promotions::LINKTO_SPECIALSPAGEIMAGE => Promotions::LINKTO_SPECIALSPAGEIMAGE,
                Promotions::LINKTO_URL => Promotions::LINKTO_URL,
                Promotions::LINKTO_PDF => Promotions::LINKTO_PDF,
                Promotions::LINKTO_PRODUCTS => Promotions::LINKTO_PRODUCTS,
                Promotions::LINKTO_NOTHING => Promotions::LINKTO_NOTHING,
            ],
            'map' => [
                Promotions::LINKTO_URL => ['url'],
                Promotions::LINKTO_PDF => ['pdf'],
                Promotions::LINKTO_PRODUCTS => [
                    'rebateText',
                    'rebateTermsLinkText',
                    'rebateTerms',
                    'manufacturers',
                    'excludeManufacturers',
                    'excludeProductSubTypes',
                    'excludeCategories',
                    'excludeProductLines',
                    'excludeProducts',
                    'productSubTypes',
                    'categories',
                    'productLines',
                    'products'
                ],
            ],
            'required' => true
        ]);
        \Phake::verify($mockFormMapper, \Phake::times(14))->end();
    }

    /**
     * Test the ConfigureList function.
     */
    public function testConfigureListFields()
    {
        $mockMapper = \Phake::mock(ListMapper::class);
        \Phake::when($mockMapper)->addIdentifier(\Phake::anyParameters())
            ->thenReturn($mockMapper);
        \Phake::when($mockMapper)->add(\Phake::anyParameters())
            ->thenReturn($mockMapper);
        $this->promotionsAdmin->configureListFields($mockMapper);
        \Phake::verify($mockMapper, \Phake::times(1))->addIdentifier(
            'title',
            null,
            [
                'template' => 'AppBundle::promotionListThumb.html.twig',
                'header_class' => 'col-md-1'
        ]);
        \Phake::verify($mockMapper, \Phake::times(1))->add('begins');
        \Phake::verify($mockMapper, \Phake::times(1))->add('ends');
        \Phake::verify($mockMapper, \Phake::times(1))->add(
            'status',
                null,
                [
                    'template' => 'AppBundle::promotionListStatus.html.twig',
                    'header_class' => 'col-md-1'
                ]
        );
        \Phake::verify($mockMapper, \Phake::times(1))->add('_action', null, [
            'header_class' => 'col-md-1',
            'actions' => [
                'Load' => [
                    'template' => 'AppBundle::promotionBulkLoadProductsButton.html.twig'
                ],
                'UnLoad' => [
                    'template' => 'AppBundle::promotionBulkUnLoadProductsButton.html.twig'
                ]
            ]
        ]);
    }

    /**
     * Test the ConfigureShow function.
    */
    public function testConfigureShowFields()
    {
        $mockMapper = \Phake::mock(ShowMapper::class);
        \Phake::when($mockMapper)->add(\Phake::anyParameters())
            ->thenReturn($mockMapper);
        $this->promotionsAdmin->configureShowFields($mockMapper);
        \Phake::verify($mockMapper, \Phake::times(1))->add('id');
        \Phake::verify($mockMapper, \Phake::times(1))->add('created');
        \Phake::verify($mockMapper, \Phake::times(1))->add('modified');
        \Phake::verify($mockMapper, \Phake::times(1))->add('updated');
        \Phake::verify($mockMapper, \Phake::times(1))->add('begins');
        \Phake::verify($mockMapper, \Phake::times(1))->add('ends');
        \Phake::verify($mockMapper, \Phake::times(1))->add('title');
        \Phake::verify($mockMapper, \Phake::times(1))->add('shortTitle');
        \Phake::verify($mockMapper, \Phake::times(1))->add('subTitle');
        \Phake::verify($mockMapper, \Phake::times(1))->add('rebatePrice');
        \Phake::verify($mockMapper, \Phake::times(1))->add('rebateText');
        \Phake::verify($mockMapper, \Phake::times(1))->add('rebateSubtext');
        \Phake::verify($mockMapper, \Phake::times(1))->add('teaser');
        \Phake::verify($mockMapper, \Phake::times(1))->add('imageListPageId');
        \Phake::verify($mockMapper, \Phake::times(1))->add('imageGlobalBannerId');
        \Phake::verify($mockMapper, \Phake::times(1))->add('showOnHomePage');
        \Phake::verify($mockMapper, \Phake::times(1))->add('showOnSpecialsPage');
        \Phake::verify($mockMapper, \Phake::times(1))->add('slug');
        \Phake::verify($mockMapper, \Phake::times(1))->add('deleted');
        \Phake::verify($mockMapper, \Phake::times(1))->add('deletedBy');
        \Phake::verify($mockMapper, \Phake::times(1))->add('deletedDate');
        \Phake::verify($mockMapper, \Phake::times(1))->add('url');
        \Phake::verify($mockMapper, \Phake::times(1))->add('linkTo');
        \Phake::verify($mockMapper, \Phake::times(1))->add('pdfName');
        \Phake::verify($mockMapper, \Phake::times(1))->add('pdf');
        \Phake::verify($mockMapper, \Phake::times(1))->add('mailInRebate');
        \Phake::verify($mockMapper, \Phake::times(1))->add('showTitleOnHomePage');
        \Phake::verify($mockMapper, \Phake::times(1))->add('rebateTerms');
        \Phake::verify($mockMapper, \Phake::times(1))->add('rebateTermsLinkText');
        \Phake::verify($mockMapper, \Phake::times(1))->add('rebateLinkText');
        \Phake::verify($mockMapper, \Phake::times(1))->add('contentsCategoryId');
        \Phake::verify($mockMapper, \Phake::times(1))->add('iframe');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promoCode');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promoAmount');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promoAmountType');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promoApplyTo');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promoMinQty');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promotionTypes');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promotionTypess');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promotionTypesService');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promotionTypesGoodyear');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promotionTypesTsn');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promotionTypesCta');
        \Phake::verify($mockMapper, \Phake::times(1))->add('buttonPrint');
        \Phake::verify($mockMapper, \Phake::times(1))->add('buttonEmail');
        \Phake::verify($mockMapper, \Phake::times(1))->add('featured');
        \Phake::verify($mockMapper, \Phake::times(1))->add('cBuilderimg');
        \Phake::verify($mockMapper, \Phake::times(1))->add('linkToGoogleFeed');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promoType');
        \Phake::verify($mockMapper, \Phake::times(1))->add('promotionsTypeProductSpecifications');
    }


    public function testConfigureSideMenuHasEditRole()
    {
        $mockSecHandler = \Phake::mock(NoopSecurityHandler::class);
        $mockRequest = \Phake::mock(\Symfony\Component\HttpFoundation\Request::class);
        $mockMenuItem  = \Phake::mock(MenuItem::class);
        $mockRouteGenerator  = \Phake::mock(DefaultRouteGenerator::class);

        $mockModelManager  = \Phake::mock(ModelManager::class);
        $mockEntityManager  = \Phake::mock(EntityManager::class);
        $mockPromotionRepository = \Phake::mock(PromotionsRepository::class);

        \Phake::when($mockModelManager)->getEntityManager(Promotions::class)
            ->thenReturn($mockEntityManager);
        \Phake::when($mockEntityManager)->getRepository(Promotions::class)
            ->thenReturn($mockPromotionRepository);


        \Phake::when($mockSecHandler)->isGranted(\Phake::anyParameters())->thenReturn(true);
        \Phake::when($mockRequest)->get(\Phake::anyParameters())->thenReturn('admin_promotion_edit');

        $this->promotionsAdmin->setModelManager($mockModelManager);
        $this->promotionsAdmin->setRequest($mockRequest);
        $this->promotionsAdmin->setSecurityHandler($mockSecHandler);
        $this->promotionsAdmin->setRouteGenerator($mockRouteGenerator);
        $this->promotionsAdmin->configureSideMenu($mockMenuItem, 'EDIT');


        \Phake::verify($mockMenuItem, \Phake::times(3))->addChild(\Phake::anyParameters());
    }

    public function testConfigureSideMenuDontHasEditRole()
    {
        $mockSecHandler = \Phake::mock(NoopSecurityHandler::class);
        $mockRequest = \Phake::mock(\Symfony\Component\HttpFoundation\Request::class);
        $mockMenuItem  = \Phake::mock(MenuItem::class);
        $mockRouteGenerator  = \Phake::mock(DefaultRouteGenerator::class);

        \Phake::when($mockSecHandler)->isGranted(\Phake::anyParameters())->thenReturn(true);
        \Phake::when($mockRequest)->get(\Phake::anyParameters())->thenReturn('admin_promotion_add');

        $this->promotionsAdmin->setRequest($mockRequest);
        $this->promotionsAdmin->setSecurityHandler($mockSecHandler);
        $this->promotionsAdmin->setRouteGenerator($mockRouteGenerator);
        $this->promotionsAdmin->configureSideMenu($mockMenuItem, 'ADD');

        \Phake::verify($mockMenuItem, \Phake::times(0))->addChild(\Phake::anyParameters());
    }
}
