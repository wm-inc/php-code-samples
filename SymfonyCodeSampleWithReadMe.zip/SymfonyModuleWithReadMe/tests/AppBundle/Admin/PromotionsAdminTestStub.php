<?php

namespace Tests\AppBundle\Admin;

use AppBundle\Admin\PromotionsAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;

class PromotionsAdminTestStub extends PromotionsAdmin
{
    public function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        parent::configureDatagridFilters($datagridMapper);
    }

    public function configureFormFields(FormMapper $formMapper)
    {
        parent::configureFormFields($formMapper);
    }

    public function configureListFields(ListMapper $listMapper)
    {
        parent::configureListFields($listMapper);
    }

    public function configureShowFields(ShowMapper $showMapper)
    {
        parent::configureShowFields($showMapper);
    }

    public function getEntityManager(?string $class = null)
    {
        return parent::getEntityManager($class);
    }

    public function getModelManager()
    {
        return parent::getModelManager();
    }
}