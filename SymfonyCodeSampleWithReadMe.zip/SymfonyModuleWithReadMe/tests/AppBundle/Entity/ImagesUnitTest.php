<?php

namespace Tests\AppBundle\Entity;

use AppBundle\Entity\Images;
use PHPUnit\Framework\TestCase;
use Common\PHP7\Tests\UnitTestProviderTrait;


class ImagesUnitTest extends TestCase
{
    use UnitTestProviderTrait;

    /**
     * @var Images
     */
    private $images;

    /**
     * Create the main Images object.
     */
    public function setUp()
    {
        parent::setUp();
        $this->images = new Images();
    }

    /**
     * Destroy the main Images object.
     */
    public function tearDown()
    {
        unset($this->images);
        parent::tearDown();
    }

    /**
     * Test the Getter and Setter for Id field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testIdGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setId($originalValue);
        $actualValue = $this->images->getId();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * Test the Getter and Setter for Name field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testNameGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setName($originalValue);
        $actualValue = $this->images->getName();
        $this->assertEquals($expectedValue, $actualValue);
    }
    /**
     * Test the Getter and Setter for Type field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testTypeGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setType($originalValue);
        $actualValue = $this->images->getType();
        $this->assertEquals($expectedValue, $actualValue);
    }
    /**
     * Test the Getter and Setter for Width field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testWidthGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setWidth($originalValue);
        $actualValue = $this->images->getWidth();
        $this->assertEquals($expectedValue, $actualValue);
    }
    /**
     * Test the Getter and Setter for Height field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testHeightGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setHeight($originalValue);
        $actualValue = $this->images->getHeight();
        $this->assertEquals($expectedValue, $actualValue);
    }
    /**
     * Test the Getter and Setter for Attr field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testAttrGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setAttr($originalValue);
        $actualValue = $this->images->getAttr();
        $this->assertEquals($expectedValue, $actualValue);
    }
    /**
     * Test the Getter and Setter for Size field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testSizeGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setSize($originalValue);
        $actualValue = $this->images->getSize();
        $this->assertEquals($expectedValue, $actualValue);
    }
    /**
     * Test the Getter and Setter for created field.
     *
     */
    public function testCreatedGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->images->setCreated($validDateTime);
        $actualValue = $this->images->getCreated();
        $this->assertEquals($validDateTime, $actualValue);
    }

    /**
     * Test the Getter and Setter for modified field.
     */
    public function testModifiedGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->images->setModified($validDateTime);
        $actualValue = $this->images->getModified();
        $this->assertSame($validDateTime, $actualValue);
    }
    /**
     * Test the Getter and Setter for deleted field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testDeletedGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setDeleted($originalValue);
        $actualValue = $this->images->getDeleted();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for deletedBy field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testDeletedByGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setDeletedBy($originalValue);
        $actualValue = $this->images->getDeletedBy();
        $this->assertTrue($expectedValue === $actualValue);
    }
    /**
     * Test the Getter and Setter for DeletedDate field.
     */
    public function testDeletedDateGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->images->setDeletedDate($validDateTime);
        $actualValue = $this->images->getDeletedDate();
        $this->assertSame($validDateTime, $actualValue);
    }
    /**
     * Test the Getter and Setter for ImageTypeId field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testImageTypeIdGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setImageTypeId($originalValue);
        $actualValue = $this->images->getImageTypeId();
        $this->assertTrue($expectedValue === $actualValue);
    }
    /**
     * Test the Getter and Setter for ImageFolderId field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testImageFolderIdGetterAndSetter($originalValue, $expectedValue)
    {
        $this->images->setImageFolderId($originalValue);
        $actualValue = $this->images->getImageFolderId();
        $this->assertTrue($expectedValue === $actualValue);
    }
    /**
     * Test the Getter and Setter for S3UpdateDate field.
     */
    public function testS3UpdateDateGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->images->setS3UpdateDate($validDateTime);
        $actualValue = $this->images->getS3UpdateDate();
        $this->assertEquals($validDateTime, $actualValue);
    }

}
