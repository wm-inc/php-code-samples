<?php

namespace Tests\AppBundle\Entity;

use AppBundle\Entity\Images;
use AppBundle\Entity\Promotions;
use PHPUnit\Framework\TestCase;
use Common\PHP7\Tests\UnitTestProviderTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class PromotionsUnitTest extends TestCase
{
    use UnitTestProviderTrait;

    const PROMOTYPE_REBATE = 'Rebate';
    const PROMOTYPE_SALE   = 'Sale';
    const PROMOTYPE_OFFER = 'Offer';
    const PROMOTYPE_MEMBERS_ONLY = 'Members Only';
    const DISPLAYAREA_RETAIL = 'Retail';
    const DISPLAYAREA_WHOLESALE = 'Wholesale';
    const PROMOTIONSTYPEPRODUCTSPECIFICATIONS_PRODUCTS   = 'products';
    const PROMOTIONSTYPEPRODUCTSPECIFICATIONS_HEIRARCHY   = 'heirarchy';
    const LINKTO_SPECIALSPAGEIMAGE  = 'Specials Page Image';
    const LINKTO_URL  = 'URL';
    const LINKTO_PDF  = 'PDF';
    const LINKTO_PRODUCTS  = 'Products';
    const LINKTO_NOTHING  = 'Nothing';

    /**
     * @var Promotions
     */
    private $promotion;

    /**
     * Create the main promotions object.
     */
    public function setUp()
    {
        parent::setUp();
        $this->promotion = new Promotions();
    }

    /**
     * Destroy the main promotions object.
     */
    public function tearDown()
    {
        unset($this->promotion);
        parent::tearDown();
    }

    /**
     * Test the Getter and Setter for Id field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testIdGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setId($originalValue);
        $actualValue = $this->promotion->getId();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * Test the Getter and Setter for eated field.
     *
     */
    public function testCreatedGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->promotion->setCreated($validDateTime);
        $actualValue = $this->promotion->getCreated();
        $this->assertEquals($validDateTime, $actualValue);
    }

    /**
     * Test the Getter and Setter for modified field.
     */
    public function testModifiedGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->promotion->setModified($validDateTime);
        $actualValue = $this->promotion->getModified();
        $this->assertSame($validDateTime, $actualValue);
    }

    /**
     * Test the Getter and Setter for Updated field.
     */
    public function testUpdatedGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->promotion->setUpdated($validDateTime);
        $actualValue = $this->promotion->getUpdated();
        $this->assertEquals($validDateTime, $actualValue);
    }

    /**
     * Test the Getter and Setter for Begins field.
     */
    public function testBeginsGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->promotion->setBegins($validDateTime);
        $actualValue = $this->promotion->getBegins();
        $this->assertSame($validDateTime, $actualValue);
    }

    /**
     * Test the Getter and Setter for ends field.
     */
    public function testEndsGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->promotion->setEnds($validDateTime);
        $actualValue = $this->promotion->getEnds();
        $this->assertEquals($validDateTime, $actualValue);
    }

    /**
     * Test the Getter and Setter for Title field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testTitleGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setTitle($originalValue);
        $actualValue = $this->promotion->getTitle();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * Test the Getter and Setter for shortTitle field.
     *
     * @dataProvider stringProvider
     *
     * @param string $originalValue
     * @param string $expectedValue
     */
    public function testShortTitleGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setShortTitle($originalValue);
        $actualValue = $this->promotion->getShortTitle();
        $this->assertEquals($expectedValue, $actualValue);
    }

    /**
     * Test the Getter and Setter for subTitle field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testSubTitleGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setSubTitle($originalValue);
        $actualValue = $this->promotion->getSubTitle();
        $this->assertSame($expectedValue, $actualValue);
    }

    /**
     * Test the Getter and Setter for rebatePrice field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testRebatePriceGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setRebatePrice($originalValue);
        $actualValue = $this->promotion->getRebatePrice();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for rebateText field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testRebateTextGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setRebateText($originalValue);
        $actualValue = $this->promotion->getRebateText();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for rebateSubtext field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testRebateSubtextGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setRebateSubtext($originalValue);
        $actualValue = $this->promotion->getRebateSubtext();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for Teaser field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testTeaserGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setTeaser($originalValue);
        $actualValue = $this->promotion->getTeaser();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for imageListPageId field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testImageListPageIdGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setImageListPageId($originalValue);
        $actualValue = $this->promotion->getImageListPageId();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for imageSpecialsPageId field.
     *
     */
    public function testImageSpecialsPageGetterAndSetter()
    {
        $expectedValue = \Phake::mock(Images::class);
        $this->promotion->setImageSpecialsPage($expectedValue);
        $actualValue = $this->promotion->getImageSpecialsPage();
        $this->assertInstanceOf(Images::class, $actualValue);
        $this->assertInstanceOf(\Phake_IMock::class, $actualValue);
        $this->assertEquals($expectedValue, $actualValue);
    }

     /**
     * Test the Getter and Setter for imageHomePageId field.
     */
    public function testImageHomePageGetterAndSetter()
    {
        $expectedValue = \Phake::mock(Images::class);
        $this->promotion->setImageHomePage($expectedValue);
        $actualValue = $this->promotion->getImageHomePage();
        $this->assertInstanceOf(Images::class, $actualValue);
        $this->assertInstanceOf(\Phake_IMock::class, $actualValue);
        $this->assertEquals($expectedValue, $actualValue);
    }
    
     /**
     * Test the Getter and Setter for imageGlobalBannerId field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testImageGlobalBannerIdGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setImageGlobalBannerId($originalValue);
        $actualValue = $this->promotion->getImageGlobalBannerId();
        $this->assertTrue($expectedValue === $actualValue);
    }
    
    /**
     * Test the Getter and Setter for showOnBrandPage field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testShowOnBrandPageGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setShowOnBrandPage($originalValue);
        $actualValue = $this->promotion->getShowOnBrandPage();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for applyOnlyMapProducts field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testApplyOnlyMapProductsGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setApplyOnlyMapProducts($originalValue);
        $actualValue = $this->promotion->getApplyOnlyMapProducts();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for showOnHomePage field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testShowOnHomePageGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setShowOnHomePage($originalValue);
        $actualValue = $this->promotion->getShowOnHomePage();
        $this->assertTrue($expectedValue === $actualValue);
    }
    
     /**
     * Test the Getter and Setter for showOnSpecialsPage field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testShowOnSpecialsPageGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setShowOnSpecialsPage($originalValue);
        $actualValue = $this->promotion->getShowOnSpecialsPage();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for slug field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProviderWithNull
     */
    public function testSlugGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setSlug($originalValue);
        $actualValue = $this->promotion->getSlug();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for deleted field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testDeletedGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setDeleted($originalValue);
        $actualValue = $this->promotion->getDeleted();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for deletedBy field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testDeletedByGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setDeletedBy($originalValue);
        $actualValue = $this->promotion->getDeletedBy();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for deletedDate field.
     */
    public function testDeletedDateGetterAndSetter()
    {
        $validDateTime = new \DateTime();
        $this->promotion->setDeletedDate($validDateTime);
        $actualValue = $this->promotion->getDeletedDate();
        $this->assertEquals($validDateTime, $actualValue);
    }

    /**
     * Test the Getter and Setter for url field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProviderWithNull
     */
    public function testUrlGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setUrl($originalValue);
        $actualValue = $this->promotion->getUrl();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testSetLinkToThrowsExceptionWhenParameterInvalid()
    {
        $invalidLinkTo = 'This is not a valid LinkTo value.';
        $this->promotion->setLinkTo($invalidLinkTo);
    }

    /**
     * Test the Getter and Setter for linkTo field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider linkToProvider
     */
    public function testLinkToGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setLinkTo($originalValue);
        $actualValue = $this->promotion->getLinkTo();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for pdfName field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testPdfNameGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPdfName($originalValue);
        $actualValue = $this->promotion->getPdfName();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for pdfName field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testPdfGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPdf($originalValue);
        $actualValue = $this->promotion->getPdf();
        $this->assertEquals($expectedValue, $actualValue);
    }

    /**
     * Test the Getter and Setter for mailInRebate field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testMailInRebateGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setMailInRebate($originalValue);
        $actualValue = $this->promotion->getMailInRebate();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for showTitleOnHomePage field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testShowTitleOnHomePageGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setShowTitleOnHomePage($originalValue);
        $actualValue = $this->promotion->getShowTitleOnHomePage();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for rebateTerms field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testRebateTermsGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setRebateTerms($originalValue);
        $actualValue = $this->promotion->getRebateTerms();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for rebateTermsLinkText field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testRebateTermsLinkTextGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setRebateTermsLinkText($originalValue);
        $actualValue = $this->promotion->getRebateTermsLinkText();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for rebateLinkText field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testRebateLinkTextGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setRebateLinkText($originalValue);
        $actualValue = $this->promotion->getRebateLinkText();
        $this->assertTrue($expectedValue === $actualValue);
    }

    public function testImageRebateIconGetterAndSetter()
    {
        $expectedValue = \Phake::mock(Images::class);
        $this->promotion->setImageRebateIcon($expectedValue);
        $actualValue = $this->promotion->getImageRebateIcon();
        $this->assertEquals($expectedValue, $actualValue);
    }

    /**
     * Test the Getter and Setter for contentsCategoryId field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testContentsCategoryIdGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setContentsCategoryId($originalValue);
        $actualValue = $this->promotion->getContentsCategoryId();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for iframe field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testIframeGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setIframe($originalValue);
        $actualValue = $this->promotion->getIframe();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for promoCode field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testPromoCodeGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromoCode($originalValue);
        $actualValue = $this->promotion->getPromoCode();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * Test the Getter and Setter for promoAmount field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testPromoAmountGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromoAmount($originalValue);
        $actualValue = $this->promotion->getPromoAmount();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promoAmountType field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testPromoAmountTypeGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromoAmountType($originalValue);
        $actualValue = $this->promotion->getPromoAmountType();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promoApplyTo field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testPromoApplyToGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromoApplyTo($originalValue);
        $actualValue = $this->promotion->getPromoApplyTo();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promoMinQty field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testPromoMinQtyGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromoMinQty($originalValue);
        $actualValue = $this->promotion->getPromoMinQty();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promotionTypes field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProviderWithNull
     */
    public function testPromotionTypesGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromotionTypes($originalValue);
        $actualValue = $this->promotion->getPromotionTypes();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promotionTypess field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProvider
     */
    public function testPromotionTypessGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromotionTypess($originalValue);
        $actualValue = $this->promotion->getPromotionTypess();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promotionTypesService field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testPromotionTypesServiceGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromotionTypesService($originalValue);
        $actualValue = $this->promotion->getPromotionTypesService();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promotionTypesGoodyear field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testPromotionTypesGoodyearGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromotionTypesGoodyear($originalValue);
        $actualValue = $this->promotion->getPromotionTypesGoodyear();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promotionTypesTsn field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testPromotionTypesTsnGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromotionTypesTsn($originalValue);
        $actualValue = $this->promotion->getPromotionTypesTsn();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for promotionTypesCta field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testPromotionTypesCtaGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromotionTypesCta($originalValue);
        $actualValue = $this->promotion->getPromotionTypesCta();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for buttonPrint field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testButtonPrintGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setButtonPrint($originalValue);
        $actualValue = $this->promotion->getButtonPrint();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for buttonEmail field.
     *
     * @param int $originalValue
     * @param int $expectedValue
     *
     * @dataProvider integerProviderWithNull
     */
    public function testButtonEmailGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setButtonEmail($originalValue);
        $actualValue = $this->promotion->getButtonEmail();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for featured field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testFeaturedGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setFeatured($originalValue);
        $actualValue = $this->promotion->getFeatured();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for cbuilderimg field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProviderWithNull
     */
    public function testCbuilderimgGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setCbuilderimg($originalValue);
        $actualValue = $this->promotion->getCbuilderimg();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Test the Getter and Setter for linkToGoogleFeed field.
     *
     * @param mixed $originalValue
     * @param bool $expectedValue
     *
     * @dataProvider booleanProvider
     */
    public function testLinkToGoogleFeedGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setLinkToGoogleFeed($originalValue);
        $actualValue = $this->promotion->getLinkToGoogleFeed();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testPromoTypeThrowsExceptionWhenParameterInvalid()
    {
        $invalidPromoType = 'This is not a valid promo type.';
        $this->promotion->setPromoType($invalidPromoType);
    }

     /**
     * Test the Getter and Setter for promoType field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider promoTypeProvider
     */
    public function testPromoTypeGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromoType($originalValue);
        $actualValue = $this->promotion->getPromoType();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testDisplayAreaThrowsExceptionWhenParameterInvalid()
    {
        $invalidDisplayArea = 'This is not a valid display area.';
        $this->promotion->setDisplayArea($invalidDisplayArea);
    }

    /**
     * Test the Getter and Setter for displayArea field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider displayAreaProvider
     */
    public function testDisplayAreaGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setDisplayArea($originalValue);
        $actualValue = $this->promotion->getDisplayArea();
        $this->assertTrue($expectedValue === $actualValue);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testSetPromotionsTypeProductSpecificationsThrowsExceptionWhenParameterInvalid()
    {
        $invalidValue = 'This is not a valid value.';
        $this->promotion->setPromotionsTypeProductSpecifications($invalidValue);
    }

     /**
     * Test the Getter and Setter for promotionsTypeProductSpecifications field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider promotionsTypeProductSpecificationsProvider
     */
    public function testPromotionsTypeProductSpecificationsGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setPromotionsTypeProductSpecifications($originalValue);
        $actualValue = $this->promotion->getPromotionsTypeProductSpecifications();
        $this->assertTrue($expectedValue === $actualValue);
    }

     /**
     * Testing whether it returns true when a Valid promo_types is passed.
     */
    public function testIsValidPromoTypeReturnsTrueWhenPromoTypeIsValid()
    {
        $validPromoType = $this->promoTypeProvider()[0][0];
        $actualValue = $this->promotion->isValidPromoType($validPromoType);
        $this->assertTrue($actualValue);
    }

    /**
     * Testing whether it returns false when an Invalid promo_types is passed.
     */
    public function testIsValidPromoTypeReturnsFalseWhenPromoTypeIsNotValid()
    {
        $invalidPromoType = 'This is not a valid promoType.';
        $actualValue = $this->promotion->isValidPromoType($invalidPromoType);
        $this->assertFalse($actualValue);
    }

    /**
     * Check whether the valid promo_types is returned or not.
     */
    public function testValidPromoTypeValuesGetter()
    {
        $validPromoTypes = [
            self::PROMOTYPE_REBATE,
            self::PROMOTYPE_SALE,
            self::PROMOTYPE_OFFER,
            self::PROMOTYPE_MEMBERS_ONLY
        ];
        $validPromoTypeList = $this->promotion->getValidPromoTypeValues();
        $this->assertEquals($validPromoTypes, $validPromoTypeList);
    }

     /**
     * Testing whether it returns true when a Valid display_area is passed.
     */
    public function testIsValidDisplayAreaReturnsTrueWhenDisplayAreaIsValid()
    {
        $validDisplayArea = $this->displayAreaProvider()[0][0];
        $actualValue = $this->promotion->isValidDisplayArea($validDisplayArea);
        $this->assertTrue($actualValue);
    }

    /**
     * Testing whether it returns false when an Invalid display_area is passed.
     */
    public function testIsValidDisplayAreaReturnsFalseWhenDisplayAreaIsNotValid()
    {
        $invalidDisplayArea = 'This is not a valid displayArea.';
        $actualValue = $this->promotion->isValidDisplayArea($invalidDisplayArea);
        $this->assertFalse($actualValue);
    }

    /**
     * Check whether the valid display_area is returned or not.
     */
    public function testValidDisplayAreaValuesGetter()
    {
        $validPromoTypes = [
            self::DISPLAYAREA_RETAIL,
            self::DISPLAYAREA_WHOLESALE
        ];
        $validDisplayAreaList = $this->promotion->getValidDisplayAreaValues();
        $this->assertEquals($validPromoTypes, $validDisplayAreaList);
    }

    /**
     * Testing whether it returns true when a Valid link_to is passed.
     */
    public function testIsValidLinkToReturnsTrueWhenLinkToIsValid()
    {
        $validLinkTo = $this->linkToProvider()[0][0];
        $actualValue = $this->promotion->isValidLinkToValues($validLinkTo);
        $this->assertTrue($actualValue);
    }

    /**
     * Testing whether it returns false when an Invalid link_to is passed.
     */
    public function testIsValidLinkToReturnsFalseWhenLinkToIsNotValid()
    {
        $invalidLinkTo = 'This is not a valid linkTo.';
        $actualValue = $this->promotion->isValidLinkToValues($invalidLinkTo);
        $this->assertFalse($actualValue);
    }

    /**
     * Check whether the valid linkTo is returned or not.
     */
    public function testValidLinkToValuesGetter()
    {
        $validLinkTo = [
            self::LINKTO_SPECIALSPAGEIMAGE,
            self::LINKTO_URL,
            self::LINKTO_PDF,
            self::LINKTO_PRODUCTS,
            self::LINKTO_NOTHING
        ];
        $validLinkToList = $this->promotion->getValidLinkToValues();
        $this->assertEquals($validLinkTo, $validLinkToList);
    }

    /**
     * Testing whether it returns true when a Valid promo_types is passed.
     */
    public function testIsPromotionsTypeProductSpecificationsTypeReturnsTrueWhenPromotionsTypeProductSpecificationsIsValid()
    {
        $validPromotionsTypeProductSpecifications = $this->promotionsTypeProductSpecificationsProvider()[0][0];
        $actualValue = $this->promotion->isValidPromotionsTypeProductSpecificationsValues(
            $validPromotionsTypeProductSpecifications
        );
        $this->assertTrue($actualValue);
    }

    /**
     * Testing whether it returns false when an Invalid promo_types is passed.
     */
    public function testIsPromotionsTypeProductSpecificationsTypeReturnsFalseWhenPromotionsTypeProductSpecificationsIsNotValid()
    {
        $invalidPromotionsTypeProductSpecifications = 'This is not a valid promotionsTypeProductSpecifications.';
        $actualValue = $this->promotion->isValidPromotionsTypeProductSpecificationsValues(
            $invalidPromotionsTypeProductSpecifications
        );
        $this->assertFalse($actualValue);
    }

    /**
     * Check whether the valid promotions_type_product_specifications is returned or not.
     */
    public function testValidPromotionsTypeProductSpecificationsValuesGetter()
    {
        $validPromotionsTypeProductSpecifications = [
            self::PROMOTIONSTYPEPRODUCTSPECIFICATIONS_PRODUCTS,
            self::PROMOTIONSTYPEPRODUCTSPECIFICATIONS_HEIRARCHY
        ];
        $validPromotionsTypeProductSpecificationsList = $this->promotion
            ->getValidPromotionsTypeProductSpecificationsValues();
        $this->assertEquals($validPromotionsTypeProductSpecifications, $validPromotionsTypeProductSpecificationsList);
    }

    public function testGetStatusImagesReturnsExpiredImageWhenPromotionExpired()
    {
        try {
            $endDate = new \DateTime();
            $endDate->sub(new \DateInterval('P1D'));
            $this->hasPromotion(null, $endDate);
            $actualImages = $this->promotion->getStatusImages();
            $this->assertTrue(is_array($actualImages));
            $this->assertEquals(2, count($actualImages));
            $this->assertEquals([
                'src' => 'clock_error.gif',
                'title' => 'Expired'
            ], $actualImages[0]);
        } catch (\Exception $e) {
            $this->fail('Exception: ' . $e->getMessage());
        }
    }

    public function testGetStatusImagesReturnsScheduledImageWhenPromotionScheduled()
    {
        try {
            $beginDate = new \DateTime();
            $beginDate->add(new \DateInterval('P1D'));
            $this->hasPromotion($beginDate);
            $actualImages = $this->promotion->getStatusImages();
            $this->assertTrue(is_array($actualImages));
            $this->assertEquals(2, count($actualImages));
            $this->assertEquals([
                'src' => 'date_go.gif',
                'title' => 'Scheduled'
            ], $actualImages[0]);
        } catch (\Exception $e) {
            $this->fail('Exception: ' . $e->getMessage());
        }
    }

    public function testGetStatusImagesReturnsActiveImageWhenPromotionActive()
    {
        try {
            $this->hasPromotion();
            $actualImages = $this->promotion->getStatusImages();
            $this->assertTrue(is_array($actualImages));
            $this->assertEquals(2, count($actualImages));
            $this->assertEquals([
                'src' => 'star.gif',
                'title' => 'Active'
            ], $actualImages[0]);
        } catch (\Exception $e) {
            $this->fail('Exception: ' . $e->getMessage());
        }
    }

    public function testGetStatusImagesReturnsHomePageImageWhenPromotionIsShownOnHomePage()
    {
        try {
            $this->hasPromotion();
            $actualImages = $this->promotion->getStatusImages();
            $this->assertTrue(is_array($actualImages));
            $this->assertEquals(2, count($actualImages));
            $this->assertEquals(
                [
                    'src' => 'house.gif',
                    'title' => 'Show on Home Page'
                ],
                $actualImages[1]
            );
        } catch (\Exception $e) {
            $this->fail('Exception: ' . $e->getMessage());
        }
    }

    public function testGetStatusImagesReturnsNothingWhenPromotionIsNotShownOnHomePage()
    {
        try {
            $this->hasPromotion(null, null, false);
            $actualImages = $this->promotion->getStatusImages();
            $this->assertTrue(is_array($actualImages));
            $this->assertEquals(1, count($actualImages));
            $this->assertEquals(
                [
                    'src' => 'star.gif',
                    'title' => 'Active'
                ],
                $actualImages[0]
            );
        } catch (\Exception $e) {
            $this->fail('Exception: ' . $e->getMessage());
        }
    }

    /**
     * PromoType Data Provider.
     *
     * @return array
     */
    public function promoTypeProvider()
    {
        return [
            [self::PROMOTYPE_REBATE, self::PROMOTYPE_REBATE],
            [self::PROMOTYPE_SALE, self::PROMOTYPE_SALE],
            [self::PROMOTYPE_OFFER, self::PROMOTYPE_OFFER],
            [self::PROMOTYPE_MEMBERS_ONLY, self::PROMOTYPE_MEMBERS_ONLY]
        ];
    }

    /**
     * DisplayArea Data Provider.
     *
     * @return array
     */
    public function displayAreaProvider()
    {
        return [
            [self::DISPLAYAREA_RETAIL, self::DISPLAYAREA_RETAIL],
            [self::DISPLAYAREA_WHOLESALE, self::DISPLAYAREA_WHOLESALE]
        ];
    }

    /**
     * promotionsTypeProductSpecifications Data Provider.
     *
     * @return array
     */
    public function promotionsTypeProductSpecificationsProvider()
    {
        return [
            [self::PROMOTIONSTYPEPRODUCTSPECIFICATIONS_PRODUCTS, self::PROMOTIONSTYPEPRODUCTSPECIFICATIONS_PRODUCTS],
            [self::PROMOTIONSTYPEPRODUCTSPECIFICATIONS_HEIRARCHY, self::PROMOTIONSTYPEPRODUCTSPECIFICATIONS_HEIRARCHY]
        ];
    }

    /**
     * LinkTo Data Provider.
     *
     * @return array
     */
    public function linkToProvider()
    {
        return [
            [self::LINKTO_SPECIALSPAGEIMAGE, self::LINKTO_SPECIALSPAGEIMAGE],
            [self::LINKTO_URL, self::LINKTO_URL],
            [self::LINKTO_PDF, self::LINKTO_PDF],
            [self::LINKTO_PRODUCTS, self::LINKTO_PRODUCTS],
            [self::LINKTO_NOTHING, self::LINKTO_NOTHING]
        ];
    }

    /**
     * @param \DateTime|null $beginDate
     * @param \DateTime|null $endDate
     * @param bool $showOnHomePage
     * @throws \Exception
     */
    private function hasPromotion(?\DateTime $beginDate = null, ?\DateTime $endDate = null, bool $showOnHomePage = true)
    {
        $now = new \DateTime();

        if (is_null($beginDate)) {
            $beginDate = clone $now;
            $beginDate->sub(new \DateInterval('P1W'));
        }
        if (is_null($endDate)) {
            $endDate = clone $now;
            $endDate->add(new \DateInterval('P1W'));
        }
        $this->promotion->setBegins($beginDate);
        $this->promotion->setEnds($endDate);
        $this->promotion->setShowOnHomePage($showOnHomePage);
    }

    public function testWholesaleGetterAndSetter()
    {
        $mockArrayCollection = \Phake::mock(ArrayCollection::class);
        $this->promotion->setWholesale($mockArrayCollection);
        $actualResult = $this->promotion->getWholesale();
        $this->assertSame($mockArrayCollection, $actualResult);
    }

    /**
     * Test the Getter and Setter for Filename field.
     *
     * @param string $originalValue
     * @param string $expectedValue
     *
     * @dataProvider stringProvider
     */
    public function testFilenameGetterAndSetter($originalValue, $expectedValue)
    {
        $this->promotion->setFilename($originalValue);
        $actualValue = $this->promotion->getFilename();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testImageEbayetterAndSetter()
    {
        $mockImage = \Phake::mock(Images::class);
        $this->promotion->setImageEbay($mockImage);
        $actualResult = $this->promotion->getImageEbay();
        $this->assertSame($mockImage, $actualResult);
    }

    public function testGetImageUrl()
    {
/*        $mockPromotion = \Phake::mock(Promotions::class);
        $mockImage = \Phake::mock(Images::class);

        \Phake::when($mockPromotion)->getId()->thenReturn(123);
        \Phake::when($mockPromotion)->getImageHomePage()->thenReturn($mockImage);
        \Phake::when($mockImage)->getName()->thenReturn('image.jpg');

        $mockPromotion->getImageUrl(Promotions::PROMOTION_IMAGE_TYPE_HOMEPAGE);
        $mockPromotion->getId();
        $mockPromotion->getImageHomePage();
        $mockImage->getName();

        \Phake::verify($mockPromotion, \Phake::times(1))->getImageUrl(\Phake::anyParameters());
        \Phake::verify($mockPromotion, \Phake::times(1))->getId();
        \Phake::verify($mockPromotion, \Phake::times(1))->getImageHomePage();
        \Phake::verify($mockImage, \Phake::times(1))->getName();*/

        if (
            (
                isset( $_SERVER['HTTP_HOST'] )
                and preg_match( '/(.jenkins|.local)/', $_SERVER['HTTP_HOST'] )
            )
            or (
                gethostname() == 'vagrant'
                or false !== stripos( gethostname(), 'jenkins' )
            )
        ) {
            $folderName = "promotions-staging";
        } else {
            $folderName = "promotions";
        }

        $image = new Images();
        $promo = new Promotions();
        $image->setName("image.jpg");
        $promo->setId(1);
        $imageName = $promo->getId()."-{$image->getName()}";
        $promo->setImageHomePage($image);
        $imageType = 'homepage';

        $expectedValue = sprintf(Promotions::PROMOTION_IMAGE_URL_TEMPLATE, $folderName, $imageType, 'thumbnail/', $imageName);
        $actualValue = $promo->getImageUrl(Promotions::PROMOTION_IMAGE_TYPE_HOMEPAGE);
        $this->assertSame($expectedValue, $actualValue);

        $promo->setImageHomePage(null);
        $image->setName('');
        $expectedValue = '';
        $actualValue = $promo->getImageUrl(Promotions::PROMOTION_IMAGE_TYPE_HOMEPAGE);
        $this->assertSame($expectedValue, $actualValue);


        $image->setName("image.jpg");
        $promo->setImageSpecialsPage($image);
        $imageType = 'special';
        $expectedValue = sprintf(Promotions::PROMOTION_IMAGE_URL_TEMPLATE, $folderName, $imageType, 'thumbnail/', $imageName);
        $actualValue = $promo->getImageUrl(Promotions::PROMOTION_IMAGE_TYPE_SPECIAL);
        $this->assertSame($expectedValue, $actualValue);

        $image->setName('');
        $promo->setImageSpecialsPage(null);
        $expectedValue = '';
        $actualValue = $promo->getImageUrl(Promotions::PROMOTION_IMAGE_TYPE_SPECIAL);
        $this->assertSame($expectedValue, $actualValue);

        $image->setName("image.jpg");
        $promo->setImageEbay($image);
        $imageType = 'ebay';
        $expectedValue = sprintf(Promotions::PROMOTION_IMAGE_URL_TEMPLATE, $folderName, $imageType, 'thumbnail/', $imageName);
        $actualValue = $promo->getImageUrl(Promotions::PROMOTION_IMAGE_TYPE_EBAY);
        $this->assertSame($expectedValue, $actualValue);

        $image->setName('');
        $promo->setImageEbay(null);
        $expectedValue = '';
        $actualValue = $promo->getImageUrl(Promotions::PROMOTION_IMAGE_TYPE_EBAY);
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testImageHomePageFileGetterAndSetter()
    {
        $expectedValue = \Phake::mock(UploadedFile::class);
        $this->promotion->setImageHomePageFile($expectedValue);
        $actualValue = $this->promotion->getImageHomePageFile();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testImageSpecialsPageFileGetterAndSetter()
    {
        $expectedValue = \Phake::mock(UploadedFile::class);
        $this->promotion->setImageSpecialsPageFile($expectedValue);
        $actualValue = $this->promotion->getImageSpecialsPageFile();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testImageEbayFileGetterAndSetter()
    {
        $expectedValue = \Phake::mock(UploadedFile::class);
        $this->promotion->setImageEbayFile($expectedValue);
        $actualValue = $this->promotion->getImageEbayFile();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testRebateIconImageFileGetterAndSetter()
    {
        $expectedValue = \Phake::mock(UploadedFile::class);
        $this->promotion->setRebateIconImageFile($expectedValue);
        $actualValue = $this->promotion->getRebateIconImageFile();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testPdfFileGetterAndSetter()
    {
        $expectedValue = \Phake::mock(UploadedFile::class);
        $this->promotion->setPdfFile($expectedValue);
        $actualValue = $this->promotion->getPdfFile();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testProductLinesGetterAndSetter()
    {
        $expectedValue = \Phake::mock(ArrayCollection::class);
        $this->promotion->setProductLines($expectedValue);
        $actualValue = $this->promotion->getProductLines();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testManufacturersGetterAndSetter()
    {
        $expectedValue = \Phake::mock(ArrayCollection::class);
        $this->promotion->setManufacturers($expectedValue);
        $actualValue = $this->promotion->getManufacturers();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testCategoriesGetterAndSetter()
    {
        $expectedValue = \Phake::mock(ArrayCollection::class);
        $this->promotion->setCategories($expectedValue);
        $actualValue = $this->promotion->getCategories();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testProductSubTypesGetterAndSetter()
    {
        $expectedValue = \Phake::mock(ArrayCollection::class);
        $this->promotion->setProductSubTypes($expectedValue);
        $actualValue = $this->promotion->getProductSubTypes();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testProductsGetterAndSetter()
    {
        $expectedValue = \Phake::mock(ArrayCollection::class);
        $this->promotion->setProducts($expectedValue);
        $actualValue = $this->promotion->getProducts();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testToString()
    {
        $expectedValue = 'Test Promotion';
        $this->promotion->setTitle($expectedValue);
        $actualValue = (string) $this->promotion;
        $this->assertSame($expectedValue, $actualValue);
    }
}
