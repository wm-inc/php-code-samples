Files in this package contains Promotions module which includes related dependency of Amazon S3 and ImageService for handling promotion images. It also  contains CSV upload for bulk associating data.

Below is the overview of features in respective folders 

src/AppBundle

    /Admin
        Contains Class for doing CRUD operations for Promotions along with uploading images to S3

    /Command

        Custom command for processing csv file on server which associates products to promotions

    /Controller
        Contains Class for routing pages for associating bulk products with Promotions using CSV upload

    /Repository
        Handles manual database interaction tasks like counting, bulk insert and update

    /Service
        Provides Global utility classes, which are used via dependency injection in admin classes

tests/
    Unit tests for classes in src/AppBundle folder