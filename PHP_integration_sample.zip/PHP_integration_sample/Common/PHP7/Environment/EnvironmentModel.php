<?php

namespace Common\PHP7\Environment;

class EnvironmentModel
{
    const ENVIRONMENT_PRODUCTION = 'prod';
    const ENVIRONMENT_STAGING = 'test';
    const ENVIRONMENT_DEVELOPMENT = 'dev';

    /**
     * @var string
     */
    private $environment;

    /**
     * @return bool
     */
    public function isNonProductionEnvironment(): bool
    {
        return $this->isDevelopmentEnvironment() || $this->isStagingEnvironment();
    }

    /**
     * EnvironmentModel constructor.
     * @param string $environment
     */
    public function __construct(string $environment = null)
    {
        if (is_null($environment)) {
            $environment = $this->determineEnvironment();
        }
        $this->setEnvironment($environment);
    }

    /**
     * @return string
     */
    public function getEnvironment(): string
    {
        return $this->environment;
    }

    /**
     * @param string $environment
     */
    public function setEnvironment(string $environment)
    {
        if (!$this->isValidEnvironment($environment)) {
            throw new \InvalidArgumentException(
                __METHOD__ . '/environment parameter must be one of ' .
                implode(', ', $this->getValidEnvironments()) . '.'
            );
        }
        $this->environment = $environment;
    }

    /**
     * @return array
     */
    public function getValidEnvironments(): array
    {
        return [
            self::ENVIRONMENT_DEVELOPMENT,
            self::ENVIRONMENT_STAGING,
            self::ENVIRONMENT_PRODUCTION
        ];
    }

    /**
     * @param string $environment
     * @return bool
     */
    public function isValidEnvironment(string $environment): bool
    {
        return in_array($environment, $this->getValidEnvironments());
    }

    /**
     * @return string
     */
    public function determineEnvironment()
    {
        if ($this->isDevelopmentEnvironment()) {
            $environment = self::ENVIRONMENT_DEVELOPMENT;
        } elseif ($this->isStagingEnvironment()) {
            $environment = self::ENVIRONMENT_STAGING;
        } else {
            $environment = self::ENVIRONMENT_PRODUCTION;
        }

        return $environment;
    }

    /**
     * @return bool
     */
    public function isDevelopmentEnvironment(): bool
    {
        $isDevelopmentEnvironment =
            (
                isset($_SERVER['HTTP_HOST']) &&
                preg_match('/(.local)/', $_SERVER['HTTP_HOST'])
            )
            || gethostname() == 'local';

        return $isDevelopmentEnvironment;
    }

    /**
     * @return bool
     */
    public function isStagingEnvironment(): bool
    {
        $isStagingEnvironment =
            (
                isset($_SERVER['HTTP_HOST'])
                and preg_match('/(.jenkins)/', $_SERVER['HTTP_HOST'])
            )
            || false !== stripos(gethostname(), 'jenkins');

        return $isStagingEnvironment;
    }

    /**
     * @return bool
     */
    public function isProductionEnvironment(): bool
    {
        return !$this->isDevelopmentEnvironment() && !$this->isStagingEnvironment();
    }
}
