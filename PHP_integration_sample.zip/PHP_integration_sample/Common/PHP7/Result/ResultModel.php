<?php


namespace Common\PHP7\Result;

class ResultModel
{
    /**
     * @var bool
     */
    private $isSuccess;
    /**
     * @var mixed
     */
    private $returnValue;
    /**
     * @var string[] This can be used to pass back error messages or even caught exception messages.
     */
    private $errorMessages;
    /**
     * @var \Throwable Can be used to indicate the exception that was caught.
     */
    private $exception;

    /**
     * @return bool
     */
    public function isSuccess(): bool
    {
        return $this->isSuccess;
    }

    /**
     * @param bool $isSuccess
     */
    public function setIsSuccess(bool $isSuccess)
    {
        $this->isSuccess = $isSuccess;
    }

    /**
     * @return mixed
     */
    public function getReturnValue()
    {
        return $this->returnValue;
    }

    /**
     * @param mixed $returnValue
     */
    public function setReturnValue($returnValue)
    {
        $this->returnValue = $returnValue;
    }

    /**
     * @return string[]
     */
    public function getErrorMessages(): array
    {
        return $this->errorMessages;
    }

    /**
     * @param string[] $errorMessages
     */
    public function setErrorMessages(array $errorMessages)
    {
        $this->errorMessages = $errorMessages;
    }

    /**
     * @param string $errorMessage
     */
    public function addErrorMessage(string $errorMessage)
    {
        $this->errorMessages[] = $errorMessage;
    }

    /**
     * @return \Throwable
     */
    public function getException(): \Throwable
    {
        return $this->exception;
    }

    /**
     * @param \Throwable $exception
     */
    public function setException(\Throwable $exception)
    {
        $this->exception = $exception;
    }
}
