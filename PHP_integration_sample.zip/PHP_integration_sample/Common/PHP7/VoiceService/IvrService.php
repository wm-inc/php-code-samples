<?php

namespace Common\PHP7\VoiceService;

use Common\PHP7\VoiceService\Provider\VoiceProviderInterface;
use Common\PHP7\VoiceService\Provider\TwilioVoiceProvider;

class IvrService
{
    /**
     * @var VoiceProviderInterface
     */
    private $voiceProvider;

    /**
     * IvrService constructor.
     * @param VoiceProviderInterface|null $voiceProvider
     */
    public function __construct($voiceProvider = null)
    {
        $this->setVoiceProvider($voiceProvider);
    }

    /**
    * @param int $digit digit get from customer
    * @param string $action action url
    * @param string $say response to customer
    * @param string $hold hold to customer
    * @return Twiml
    */
    public function sendVoice($digit, $action, $say, $hold, $dial)
    {
        $voiceProvider = $this->getVoiceProvider();
        $twiml = $voiceProvider->sendVoice($digit, $action, $say, $hold, $dial);
        return $twiml;
    }

    /**
     * @return VoiceProviderInterface
     */
    public function getVoiceProvider()
    {
        return $this->voiceProvider;
    }

    /**
     * @param VoiceProviderInterface $voiceProvider
     */
    public function setVoiceProvider($voiceProvider)
    {
        if (is_null($voiceProvider)) {
            $voiceProvider = new TwilioVoiceProvider();
        }

        if (!$voiceProvider instanceof VoiceProviderInterface) {
            throw new \InvalidArgumentException(
                __METHOD__ .
                '/VoiceProvider parameter must be null or an instance of VoiceProviderInterface'
            );
        }

        $this->voiceProvider = $voiceProvider;
    }
}