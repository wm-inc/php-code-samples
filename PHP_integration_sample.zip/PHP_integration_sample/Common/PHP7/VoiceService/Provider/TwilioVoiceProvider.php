<?php

namespace Common\PHP7\VoiceService\Provider;

use Twilio\Twiml;


class TwilioVoiceProvider implements VoiceProviderInterface
{
    const PHONE_NUMBER = '1234567890';
    
    /**
     * @var Twiml
     */
    private $twilio;

    /**
     * TwilioVoiceProvider constructor.
     * @param Twiml|null $twilio
     * @throws \Twilio\Exceptions\TwimlException
     */
    public function __construct($twilio = null)
    {
        $this->setTwilio($twilio);
    }

    /**
     * @param int $digit digit get from customer
     * @param string $action action url
     * @param string $say response to customer
     * @param string $hold hold to customer
     * @return Twiml
     * @throws \Twilio\Exceptions\TwimlException
     */
    public function sendVoice($digit, $action, $say, $hold, $dial)
    {
        $twiml = $this->getTwilio();
        if (!empty($digit) && !empty($action)) {
            $gather = $twiml->gather(
                [
                    'numDigits' => $digit,
                    'action' => $action
                ]
            );
            if (!empty($hold)) {
                $gather->say(
                    $hold,
                    ['voice' => 'alice', 'language' => 'en-US', 'loop' => 1]
                );
                $gather->pause(
                    ['length' => 2]
                );
            }
            for ($i=0; $i<=1;$i++) {
                $gather->say(
                    $say,
                    ['voice' => 'alice', 'language' => 'en-US', 'loop' => 1]
                );
                $gather->pause(
                    ['length' => 10]
                );
            }
            $twiml->say(
                'We have not received any input. Redirecting to main menu.',
                ['voice' => 'alice', 'language' => 'en-US']
            );
            $twiml->dial(self::PHONE_NUMBER);
        } else {
            $twiml->say(
                $say,
                ['voice' => 'alice', 'language' => 'en-US']
            );
            $twiml->dial($dial);
        }
        return $twiml;
    }

    /**
     * @return Twiml
     */
    public function getTwilio()
    {
        return $this->twilio;
    }

    /**
     * @param Twiml|null $twilio
     * @throws \Twilio\Exceptions\TwimlException
     */
    public function setTwilio($twilio = null)
    {
        if (is_null($twilio)) {
            $twilio = new Twiml();
        }
        $this->twilio = $twilio;
    }
}
