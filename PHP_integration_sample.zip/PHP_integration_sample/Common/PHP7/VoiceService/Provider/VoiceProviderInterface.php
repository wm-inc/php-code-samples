<?php

namespace Common\PHP7\VoiceService\Provider;

use Twilio\Twiml;

interface VoiceProviderInterface
{
    /**
    * @param int $digit digit get from customer
    * @param string $action action url
    * @param string $say response to customer
    * @param string $hold hold to customer
    * @return Twiml
    */
    public function sendVoice($digit, $action, $say, $hold, $dial);
}
