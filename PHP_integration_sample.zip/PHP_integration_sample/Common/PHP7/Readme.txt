Integration of Twilio services for SMS and IVR with Service-oriented Architecture (SOA) PHP7.

- Main Classes : Setups the service and call the API
	\SmsMessage\TextMessageService
	\VoiceService\IvrService

- Dependency Classes : Environment and API return result check
	\Environment\EnvironmentModel
	\Result\ResultModel

- Unit Test : Unit test for functions and code coverage.
	\tests