<?php

namespace Common\PHP7\Tests\Result;

use Common\PHP7\Result\ResultModel;
use PHPUnit\Framework\TestCase;
use Common\PHP7\Tests\UnitTestProviderTrait;

class ResultModelUnitTest extends TestCase
{
    use UnitTestProviderTrait;

    /**
     * @var ResultModel
     */
    private $resultModel;

    public function setUp()
    {
        parent::setUp();
        $this->resultModel = new ResultModel();
    }

    public function tearDown()
    {
        unset($this->resultModel);
        parent::tearDown();
    }

    /**
     * @dataProvider stringProviderWithNull
     */
    public function testReturnValueGetterAndSetterWithStrings($testValue, $expectedValue)
    {
        $this->resultModel->setReturnValue($testValue);
        $actualValue = $this->resultModel->getReturnValue();
        // Using assertEquals here because we want value type casting since returnValue is mixed type.
        $this->assertEquals($expectedValue, $actualValue);
    }
    
    public function testErrorMessagesSetterAndGetter()
    {
        $validMessages = $this->getValidErrorMessages();
        $this->resultModel->setErrorMessages($validMessages);
        $actualMessages = $this->resultModel->getErrorMessages();
        $this->assertSame($validMessages, $actualMessages);
    }

    public function testAddErrorMessage()
    {
        $validMessages = $this->getValidErrorMessages();
        foreach ($validMessages as $validMessage) {
            $this->resultModel->addErrorMessage($validMessage);
        }
        $actualMessages = $this->resultModel->getErrorMessages();
        $this->assertSame($validMessages, $actualMessages);
    }

    /**
     * @dataProvider booleanProvider
     */
    public function testIsSuccessGetterAndSetter($testValue, $expectedValue)
    {
        $this->resultModel->setIsSuccess($testValue);
        $actualValue = $this->resultModel->isSuccess();
        $this->assertSame($expectedValue, $actualValue);
    }

    public function testExceptionGetterAndSetter()
    {
        $expectedException = new \Exception('Something bad happened', 123);
        $this->resultModel->setException($expectedException);
        $actualException = $this->resultModel->getException();
        $this->assertSame($expectedException, $actualException);
    }

    /**
     * @return array
     */
    protected function getValidErrorMessages(): array
    {
        return [
            'error 1',
            'some other error',
            'you have really bad code if you have this many errors',
        ];
    }
}
