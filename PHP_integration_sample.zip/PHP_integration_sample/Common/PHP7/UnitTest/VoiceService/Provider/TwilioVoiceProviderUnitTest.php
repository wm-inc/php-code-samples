<?php

namespace Common\PHP7\Tests\VoiceService\Provider;

use Common\PHP7\VoiceService\Provider\TwilioVoiceProvider;
use PHPUnit\Framework\TestCase;
use Twilio\Twiml;
use Twilio\TwiML\Voice\Gather;

class TwilioVoiceProviderUnitTest extends TestCase
{
    /**
     * @var TwilioVoiceProvider
     */
    private $twilioVoiceProvider;
    /**
     * @var Gather
     */
    private $mockGather;
    /**
     * @var Twiml
     */
    private $mockTwiml;

    /**
     * Create the main Twilio object.
     */
    public function setUp()
    {
        parent::setUp();
        $this->mockTwiml = \Phake::mock(Twiml::class);
        $this->mockGather = \Phake::mock(Gather::class);
        \Phake::when($this->mockTwiml)->gather(\Phake::anyParameters())
            ->thenReturn($this->mockGather);
        $this->twilioVoiceProvider = new TwilioVoiceProvider($this->mockTwiml);
    }

    /**
     * Destroy the main Twilio object.
     */
    public function tearDown()
    {
        unset($this->twilioVoiceProvider);
        parent::tearDown();
    }

    /**
    * test constructor with no params
    */
    public function testConstructWithNoParameter()
    {
        $actualTwiml = $this->twilioVoiceProvider->getTwilio();
        $this->assertInstanceOf(Twiml::class, $actualTwiml);
    }

    /**
    * test constructor with params
    */
    public function testConstructWithParameter()
    {
        $mockTwiml = \Phake::mock(Twiml::class);
        $this->twilioVoiceProvider = new TwilioVoiceProvider($mockTwiml);
        $actualTwiml = $this->twilioVoiceProvider->getTwilio();
        $this->assertInstanceOf(Twiml::class, $actualTwiml);
        $this->assertInstanceOf(\Phake_IMock::class, $actualTwiml);
    }

    /**
    * get and set twilio provider
    */
    public function testGetterSetterTwilio()
    {
        $this->twilioVoiceProvider->setTwilio(null);
        $actualTwiml = $this->twilioVoiceProvider->getTwilio();
        $this->assertInstanceOf(Twiml::class, $actualTwiml);
    }

    /**
    * test send voice function with digit and action params
    */
    public function testSendVoiceWhenDigitAndActionAreNotEmpty()
    {
        $digit = '1';
        $action = 'This is a valid action';
        $say = 'I have something important to say.';
        $hold = 'Inform Customer to hold';
        $dial = TwilioVoiceProvider::NEXTIVA_PHONE_NUMBER;
        $actualResult = $this->twilioVoiceProvider->sendVoice($digit, $action, $say, $hold, $dial);
        \Phake::verify($this->mockTwiml, \Phake::times(1))->gather(
            [
                'numDigits' => $digit,
                'action' => $action
            ]
        );
        \Phake::verify($this->mockGather, \Phake::times(0))->say(
            $say,
            ['voice' => 'alice', 'language' => 'en-US', 'loop' => 2]
        );
        \Phake::verify($this->mockTwiml, \Phake::times(1))->say(
            'We have not received any input. Redirecting to main menu.',
            ['voice' => 'alice', 'language' => 'en-US']
        );
        \Phake::verify($this->mockTwiml, \Phake::times(1))->dial(TwilioVoiceProvider::NEXTIVA_PHONE_NUMBER);
    }

    /**
    *  test send voice with empty digit and action
    */
    public function testSendVoiceWhenDigitAndActionAreEmpty()
    {
        $digit = '';
        $action = '';
        $say = 'We have not received any input. Redirecting to main menu.';
        $hold = '';
        $dial = TwilioVoiceProvider::NEXTIVA_PHONE_NUMBER;
        $actualResult = $this->twilioVoiceProvider->sendVoice($digit, $action, $say, $hold, $dial);
        \Phake::verify($this->mockTwiml, \Phake::times(1))->say(
            'We have not received any input. Redirecting to main menu.',
            ['voice' => 'alice', 'language' => 'en-US']
        );
        \Phake::verify($this->mockTwiml, \Phake::times(1))->dial(TwilioVoiceProvider::NEXTIVA_PHONE_NUMBER);
    }
}
