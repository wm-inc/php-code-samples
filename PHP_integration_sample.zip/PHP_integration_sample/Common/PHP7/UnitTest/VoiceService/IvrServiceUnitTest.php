<?php

namespace Common\PHP7\Tests\VoiceService;

use PHPUnit\Framework\Constraint\ArrayHasKey;
use Common\PHP7\VoiceService\Provider\VoiceProviderInterface;
use Common\PHP7\VoiceService\Provider\TwilioVoiceProvider;
use Common\PHP7\VoiceService\IvrService;
use PHPUnit\Framework\TestCase;
use Common\PHP7\Environment\EnvironmentModel;
use Twilio\Twiml;

class IvrServiceUnitTest extends TestCase
{
    /**
     * @var IvrService
     */
    private $ivrService;
    /**
     * @var VoiceProviderInterface
     */
    private $mockVoiceProvider;
    /**
     * @var EnvironmentModel
     */
    private $mockEnvironmentModel;
    /**
     * @var int $digit
     */
    private $digit;
    /**
     * @var string $action
     */
    private $action;
    /**
     * @var string $sayToCustomer
     */
    private $sayToCustomer;
    /**
     * @var string $hold
     */
    private $hold;
    /**
     * @var string $dial
     */
    private $dial;
    /**
     * @var Twiml
     */
    private $mockTwiml;

    /**
     * Create the main IVR object.
     */
    public function setUp()
    {
        parent::setUp();
        $this->digit  = 10;
        $this->action = "http://api.url/funcationName/0cfc3f81e47a6b6e06099cf890417d57";
        $this->sayToCustomer  =  "You are in IVR";
        $this->hold  =  "Inform customer to hold";
        $this->mockEnvironmentModel = \Phake::mock(EnvironmentModel::class);
        $this->mockTwiml = \Phake::mock(Twiml::class);
        $this->mockVoiceProvider = \Phake::mock(TwilioVoiceProvider::class);
        \Phake::when($this->mockVoiceProvider)->sendVoice(\Phake::anyParameters())
            ->thenReturn($this->mockTwiml);
        $this->ivrService = new IvrService($this->mockVoiceProvider);
    }

    /**
     * Test the Getter and Setter for voiceProvider field.
     */
    public function testVoiceProviderGetterAndSetter()
    {
        $this->mockVoiceProvider = \Phake::mock(TwilioVoiceProvider::class);
        $this->ivrService->setVoiceProvider($this->mockVoiceProvider);
        $actualVoiceProvider = $this->ivrService->getVoiceProvider();
        $this->assertSame($this->mockVoiceProvider, $actualVoiceProvider);
    }

    /**
     * Test the Getter and Setter for voiceProvider field.
     */
    public function testVoiceProviderGetterAndSetterWithNull()
    {
        $this->ivrService->setVoiceProvider(null);
        $actualVoiceProvider = $this->ivrService->getVoiceProvider();
        $this->assertInstanceOf(TwilioVoiceProvider::class, $actualVoiceProvider);
    }

    /**
    * @expectedException \InvalidArgumentException
    */
    public function testVoiceProviderWhenObjectNotAnInstanceOfTwilioVoiceProvider()
    {
        $invalidType = 'this is not a valid type';
        $this->ivrService->setVoiceProvider($invalidType);
    }

    /**
    * test Send Voice
    */
    public function testSendVoice()
    {
        $actualVoiceProvider = $this->ivrService->sendVoice($this->digit, $this->action, $this->sayToCustomer, $this->hold, $this->dial);
        \Phake::verify($this->mockVoiceProvider, \Phake::times(1))
            ->sendVoice($this->digit, $this->action, $this->sayToCustomer, $this->hold, $this->dial);
        $this->assertInstanceOf(Twiml::class, $actualVoiceProvider);
        $this->assertInstanceOf(\Phake_IMock::class, $actualVoiceProvider);
    }
}