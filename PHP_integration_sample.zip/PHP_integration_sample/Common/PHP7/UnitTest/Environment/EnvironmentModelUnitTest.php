<?php

namespace Common\PHP7\Tests\Environment;

use PHPUnit\Framework\TestCase;
use Common\PHP7\Environment\EnvironmentModel;

class EnvironmentModelUnitTest extends TestCase
{
    /**
     * @var EnvironmentModel
     */
    private $environmentModel;

    public function setUp()
    {
        parent::setUp();
    }

    public function tearDown()
    {
        $_SERVER['HTTP_HOST'] = '';
        unset($this->environmentModel);
        parent::tearDown();
    }

    public function testConstants()
    {
        $this->assertSame('prod', EnvironmentModel::ENVIRONMENT_PRODUCTION);
        $this->assertSame('test', EnvironmentModel::ENVIRONMENT_STAGING);
        $this->assertSame('dev', EnvironmentModel::ENVIRONMENT_DEVELOPMENT);
    }

    public function testGetValidEnvironments()
    {
        $this->hasEnvironmentModel();
        $expectedEnvironments = [
            EnvironmentModel::ENVIRONMENT_DEVELOPMENT,
            EnvironmentModel::ENVIRONMENT_STAGING,
            EnvironmentModel::ENVIRONMENT_PRODUCTION
        ];
        $actualEnvironments = $this->environmentModel->getValidEnvironments();
        $this->assertSame($expectedEnvironments, $actualEnvironments);
    }

    /**
     * @dataProvider isValidEnvironmentProvider
     * @param mixed $testValue
     * @param bool $expectedValue
     */
    public function testIsValidEnvironment($testValue, bool $expectedValue)
    {
        $this->hasEnvironmentModel();
        $actualResult = $this->environmentModel->isValidEnvironment($testValue);
        $this->assertSame($expectedValue, $actualResult);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testSetEnvironmentThrowsExceptionWhenEnvironmentIsInvalid()
    {
        $invalidEnvironment = 'some random environment';
        $this->hasEnvironmentModel();
        $this->environmentModel->setEnvironment($invalidEnvironment);
    }

    public function testEnvironmentGetterAndSetter()
    {
        $expectedEnvironemt = EnvironmentModel::ENVIRONMENT_PRODUCTION;
        $this->hasEnvironmentModel();
        $this->environmentModel->setEnvironment($expectedEnvironemt);
        $actualEnvironment = $this->environmentModel->getEnvironment();
        $this->assertSame($expectedEnvironemt, $actualEnvironment);
    }

    public function testConstruct()
    {
        $expectedEnvironment = EnvironmentModel::ENVIRONMENT_PRODUCTION;
        $this->environmentModel = new EnvironmentModel($expectedEnvironment);
        $actualEnvironment = $this->environmentModel->getEnvironment();
        $this->assertSame($expectedEnvironment, $actualEnvironment);
    }

    public function testIsDevelopmentEnvironmentReturnsTrueWhenHttpHostContainsLocal()
    {
        $this->hasEnvironmentModel();
        $this->hasDevelopmentHost();
        $actualValue = $this->environmentModel->isDevelopmentEnvironment();
        $this->assertTrue($actualValue);
    }

    public function testIsDevelopmentEnvironmentReturnsFalseWhenHttpHostDoesNotContainLocal()
    {
        $this->markTestSkipped('Cannot change return value of gethostname');
        $this->hasEnvironmentModel();
        $actualValue = $this->environmentModel->isDevelopmentEnvironment();
        $this->assertFalse($actualValue);
        // Check staging specifically.
        $this->hasStagingHost();
        $actualValue = $this->environmentModel->isDevelopmentEnvironment();
        $this->assertFalse($actualValue);
    }

    public function testIsStagingEnvironmentReturnsTrueWhenHttpHostContainsJenkins()
    {
        $this->hasEnvironmentModel();
        $this->hasStagingHost();
        $actualValue = $this->environmentModel->isStagingEnvironment();
        $this->assertTrue($actualValue);
    }

    public function testIsStagingEnvironmentReturnsFalseWhenHttpHostDoesNotContainJenkins()
    {
        $this->markTestSkipped('Cannot change return value of gethostname');
    }

    public function testIsProductionEnvironmentReturnsFalseWhenHttpHostIsDevelopment()
    {
        $this->hasEnvironmentModel();
        $this->hasDevelopmentHost();
        $actualValue = $this->environmentModel->isProductionEnvironment();
        $this->assertFalse($actualValue);
    }

    public function testIsProductionEnvironmentReturnsFalseWhenHttpHostIsStaging()
    {
        $this->hasEnvironmentModel();
        $this->hasStagingHost();
        $actualValue = $this->environmentModel->isProductionEnvironment();
        $this->assertFalse($actualValue);
    }

    //<editor-fold desc="*** Helper functions ***">
    /**
     * @param string $environment
     */
    private function hasEnvironmentModel($environment = 'dev')
    {
        $this->environmentModel = new EnvironmentModel($environment);
    }

    private function hasDevelopmentHost()
    {
        $_SERVER['HTTP_HOST'] = 'local';
    }

    private function hasStagingHost()
    {
        $_SERVER['HTTP_HOST'] = 'master-common.jenkins.com';
    }

    public function isValidEnvironmentProvider()
    {
        return [
            ['dev', true],
            ['test', true],
            ['prod', true],
            [0, false],
            ['', false]
        ];
    }
    //</editor-fold>
}
