<?php

namespace Common\PHP7\SmsMessage;

use Common\PHP7\Result\ResultModel;
use Common\PHP7\SmsMessage\Provider\TextMessageProviderInterface;
use Common\PHP7\SmsMessage\Provider\TwilioTextMessageProvider;

class TextMessageService
{
    /**
     * @var TextMessageProviderInterface
     */
    private $textMessageProvider;

    public function __construct($textMessageProvider = null)
    {
        $this->setTextMessageProvider($textMessageProvider);
    }

    /**
     * @param int $mobileNumber
     * @param string $message
     * @return ResultModel
     */
    public function sendText($mobileNumber, $message)
    {
        // @todo validate mobileNumber is integer and message is less than max length for SMS message.
        $textMessageProvider = $this->getTextMessageProvider();
        $resultModel = $textMessageProvider->sendText($mobileNumber, $message);

        return $resultModel;
    }

    /**
     * @return TextMessageProviderInterface
     */
    protected function getTextMessageProvider()
    {
        return $this->textMessageProvider;
    }

    /**
     * @param TextMessageProviderInterface $textMessageProvider
     */
    public function setTextMessageProvider($textMessageProvider)
    {
        if (is_null($textMessageProvider)) {
            $textMessageProvider = new TwilioTextMessageProvider();
        }

        if (!$textMessageProvider instanceof TextMessageProviderInterface) {
            throw new \InvalidArgumentException(
                __METHOD__ .
                '/textMessageProvider parameter must be null or an instance of TextMessageProviderInterface'
            );
        }

        $this->textMessageProvider = $textMessageProvider;
    }
}