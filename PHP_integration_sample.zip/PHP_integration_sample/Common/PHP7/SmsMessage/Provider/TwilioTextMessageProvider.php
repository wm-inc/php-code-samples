<?php

namespace Common\PHP7\SmsMessage\Provider;

use Twilio\Exceptions\ConfigurationException;
use Twilio\Rest\Api\V2010\Account\MessageInstance;
use Twilio\Rest\Client;
use Common\PHP7\Result\ResultModel;

class TwilioTextMessageProvider implements TextMessageProviderInterface
{
    const ACCOUNT_SID = 'XXXXXXXXXX';
    const AUTH_TOKEN = 'XXXXXXXXXX';
    const TWILIO_NUMBER = '+1234567890';

    /**
     * @var Client;
     */
    private $client;
    /**
     * @var string Twilio account ID
     */
    private $accountId;
    /**
     * @var string Twilio auth token
     */
    private $authToken;
    /**
     * @var string Phone number that text will originate from.
     */
    private $fromNumber;

    /**
     * TwilioTextMessageProvider constructor.
     * Either pass in a client or pass in the credentials and a client will be created with those credentials.
     * @todo Move auth info into a config file and remove default param values.
     * @param Client $client
     * @param string $accountId
     * @param string $authToken
     * @param string $fromNumber
     */
    public function __construct(
        $client = null,
        $accountId = 'XXXXXXXXXX',
        $authToken = 'XXXXXXXXXX',
        $fromNumber = '+1234567890'
    ) {
        // @todo Inject a factory class that would accept the credentials and create a client with those credentials.
        $this->setAccountId($accountId);
        $this->setAuthToken($authToken);
        $this->setFromNumber($fromNumber);
        $this->setClient($client);
    }

    /**
     * @param int $mobileNumber
     * @param string $message
     * @return ResultModel
     */
    public function sendText($mobileNumber, $message)
    {
        $resultModel = new ResultModel();
        try {
            $client = $this->getClient();
            /**
             * @var MessageInstance $messageInstance
             */
            $messageInstance = $client->messages->create(
                $mobileNumber,
                [
                    'from' => $this->getFromNumber(),
                    'body' => $message
                ]
            );
            $isSuccess = is_null($messageInstance->errorCode);
            if (!$isSuccess) {
                $resultModel->setErrorMessages([$messageInstance->errorMessage]);
            }
            $resultModel->setIsSuccess($isSuccess);
            $resultModel->setReturnValue($messageInstance);
        } catch (\Exception $e) {
            $resultModel->setIsSuccess(false);
            $resultModel->setException($e);
        }

        return $resultModel;
    }

    /**
     * @return Client
     */
    public function getClient()
    {
        return $this->client;
    }

    /**
     * @param Client $client
     * @throws \InvalidArgumentException
     */
    public function setClient(Client $client = null)
    {
        if (is_null($client)) {
            try {
                $client = new Client($this->getAccountId(), $this->getAuthToken());
            } catch (ConfigurationException $ce) {
                // @todo Log the exception message.
            }
        }

        if (!$client instanceof Client) {
            throw new \InvalidArgumentException(
                __METHOD__ . '/client parameter must be null or an instance of ' . Client::class
            );
        }
        $this->client = $client;
    }

    /**
     * @return string
     */
    public function getAccountId()
    {
        return $this->accountId;
    }

    /**
     * @param string $accountId
     */
    public function setAccountId($accountId)
    {
        $this->accountId = $accountId;
    }

    /**
     * @return string
     */
    public function getAuthToken()
    {
        return $this->authToken;
    }

    /**
     * @param string $authToken
     */
    public function setAuthToken($authToken)
    {
        $this->authToken = $authToken;
    }

    /**
     * @return string
     */
    public function getFromNumber()
    {
        return $this->fromNumber;
    }

    /**
     * @param string $fromNumber
     */
    public function setFromNumber($fromNumber)
    {
        $this->fromNumber = $fromNumber;
    }
}
