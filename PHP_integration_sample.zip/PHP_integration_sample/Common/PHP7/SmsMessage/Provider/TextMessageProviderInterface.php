<?php

namespace Common\PHP7\SmsMessage\Provider;

use Common\PHP7\Result\ResultModel;

interface TextMessageProviderInterface
{
    /**
     * @param int $mobileNumber
     * @param string $message
     * @return ResultModel
     */
    public function sendText($mobileNumber, $message);
}
